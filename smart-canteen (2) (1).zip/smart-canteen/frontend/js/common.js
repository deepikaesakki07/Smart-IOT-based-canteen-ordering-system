// Shared helpers used by every page
const Auth = {
  get token() { return localStorage.getItem('token'); },
  get user() { try { return JSON.parse(localStorage.getItem('user')); } catch (e) { return null; } },
  save(token, user) { localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(user)); },
  logout() { localStorage.removeItem('token'); localStorage.removeItem('user'); location.href = '/index.html'; },
  require(role) { if (!this.token || !this.user || this.user.role !== role) this.logout(); },
};

// fetch wrapper: adds the JWT and turns errors into exceptions
async function api(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && Auth.token) headers.Authorization = 'Bearer ' + Auth.token;
  const res = await fetch('/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = {};
  try { data = await res.json(); } catch (e) { /* empty body */ }
  if (res.status === 401 && auth) { Auth.logout(); throw new Error('Session expired'); }
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
}

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => '₹' + Number(n).toFixed(0);
const levelLabel = (l) => String(l || '').replace('_', ' ');
const fmtTime = (d) => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const fmtDateTime = (d) => new Date(d).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

// Bootstrap toast (type: success | info | warning | danger)
function toast(message, type = 'info') {
  let wrap = $('toastWrap');
  if (!wrap) { wrap = document.createElement('div'); wrap.id = 'toastWrap'; wrap.className = 'toast-wrap'; document.body.appendChild(wrap); }
  const el = document.createElement('div');
  el.className = `toast align-items-center text-bg-${type} border-0 mb-2`;
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${esc(message)}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  wrap.appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 5000 });
  t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}
const toastType = (t) => ({ FOOD: 'warning', ALERT: 'danger', EMERGENCY: 'danger', PICKUP: 'success', ORDER: 'info', CROWD: 'info', CLOSING: 'warning' }[t] || 'info');

function connectSocket() { return io({ auth: { token: Auth.token } }); }

// Chart.js helper: create or update a chart on a canvas
const charts = {};
function drawChart(id, config) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart($(id), { ...config, options: { responsive: true, maintainAspectRatio: false, ...(config.options || {}) } });
}
