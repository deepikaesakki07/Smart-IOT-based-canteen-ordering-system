Auth.require('ADMIN');

const S = { foods: [], cats: [], seats: [], seatSummary: null, section: 'overview', editId: null };
const ST_BADGE = { AVAILABLE: 'success', LOW_STOCK: 'warning text-dark', NEEDS_RESTOCK: 'warning text-dark', OUT_OF_STOCK: 'secondary' };
const OR_BADGE = { PENDING: 'secondary', CONFIRMED: 'info', ACCEPTED: 'primary', PREPARING: 'warning text-dark', READY: 'success', COMPLETED: 'dark', CANCELLED: 'danger' };
const FRESH_BADGE = { GOOD: 'success', WARNING: 'warning text-dark', EXPIRED: 'danger' };
const SEAT_COLOR = { AVAILABLE: '#2f9e44', OCCUPIED: '#e03131', RESERVED: '#f59f00', CLEANING: '#1c7ed6' };
const COLORS = ['#e8590c', '#2f9e44', '#1c7ed6', '#f59f00', '#7048e8', '#e03131', '#0c8599', '#868e96'];

// ---------- Navigation ----------
function show(sec) {
  S.section = sec;
  document.querySelectorAll('.admin-section').forEach((e) => e.classList.toggle('active', e.id === 'sec-' + sec));
  document.querySelectorAll('.sidebar a[data-sec]').forEach((a) => a.classList.toggle('active', a.dataset.sec === sec));
  ({ overview: loadOverview, food: loadFood, orders: loadOrders, customers: loadCustomers, seats: loadSeats,
    crowd: loadCrowd, iot: loadIot, waste: loadWaste, announce: loadAnnouncements }[sec])().catch((e) => toast(e.message, 'danger'));
}
$('sidebar').addEventListener('click', (e) => { const a = e.target.closest('a[data-sec]'); if (a) show(a.dataset.sec); });
$('logoutLink').addEventListener('click', () => Auth.logout());

// ---------- Overview ----------
async function loadOverview() {
  const [s, a] = await Promise.all([api('/admin/stats'), api('/admin/analytics')]);
  const cards = [
    ['👤', 'Total Customers', s.totalCustomers, ''], ['🧾', "Today's Orders", s.todaysOrders, ''],
    ['⏳', 'Pending Orders', s.pendingOrders, 'in the kitchen queue'], ['🪑', 'Available Seats', `${s.seats.AVAILABLE}/${s.seats.total}`, ''],
    ['👥', 'Current Crowd', `<span class="badge lvl-${s.crowd.level}">${levelLabel(s.crowd.level)}</span>`, `${s.crowd.people_count}/${s.crowd.max_capacity} people`],
    ['⚠️', 'Low Stock Items', s.lowStockItems, 'low / restock / out'], ['♻️', "Today's Food Waste", s.todaysWaste + ' kg', ''],
    ['📡', 'Active IoT Sensors', `${s.activeSensors}/${s.totalSensors}`, 'sent data in last 2 min'],
  ];
  $('statCards').innerHTML = cards.map(([i, l, v, sub]) => `<div class="col-6 col-xl-3"><div class="card stat-card"><span class="stat-icon">${i}</span>
    <div class="label">${l}</div><div class="value">${v}</div><div class="sub">${sub}</div></div></div>`).join('');
  $('orderBadge').textContent = s.pendingOrders; $('orderBadge').classList.toggle('d-none', !s.pendingOrders);

  drawChart('chDaily', { type: 'bar', data: { labels: a.dailyOrders.map((r) => r.date.slice(5)), datasets: [{ label: 'Orders', data: a.dailyOrders.map((r) => r.count), backgroundColor: '#e8590c' }] }, options: { plugins: { legend: { display: false } } } });
  drawChart('chCrowd', { type: 'line', data: { labels: a.crowdTrend.map((r) => fmtTime(r.recorded_at)), datasets: [{ label: 'People', data: a.crowdTrend.map((r) => r.people_count), borderColor: '#1c7ed6', backgroundColor: 'rgba(28,126,214,.12)', fill: true, tension: .3 }] }, options: { plugins: { legend: { display: false } } } });
  drawChart('chSales', { type: 'bar', data: { labels: a.foodSales.map((r) => r.name), datasets: [{ data: a.foodSales.map((r) => r.qty), backgroundColor: '#2f9e44' }] }, options: { indexAxis: 'y', plugins: { legend: { display: false } } } });
  drawChart('chWaste', { type: 'line', data: { labels: a.wasteTrend.map((r) => r.date.slice(5)), datasets: [{ data: a.wasteTrend.map((r) => r.kg), borderColor: '#7048e8', tension: .3 }] }, options: { plugins: { legend: { display: false } } } });
  const so = a.seatOccupancy;
  drawChart('chSeats', { type: 'doughnut', data: { labels: ['Available', 'Occupied', 'Reserved', 'Cleaning'], datasets: [{ data: [so.AVAILABLE, so.OCCUPIED, so.RESERVED, so.CLEANING], backgroundColor: Object.values(SEAT_COLOR) }] }, options: { plugins: { legend: { position: 'bottom' } } } });
}

// ---------- Food ----------
async function loadFood() {
  [S.foods, S.cats] = await Promise.all([api('/food'), api('/food/categories')]);
  renderFood();
}
function renderFood() {
  $('foodBody').innerHTML = S.foods.map((f) => `<tr>
    <td class="fs-4">${esc(f.emoji)}</td><td>${esc(f.name)} ${f.is_special ? '⭐' : ''}</td><td>${esc(f.category || '')}</td><td>${money(f.price)}</td>
    <td>${f.quantity}</td><td>${f.min_stock}</td>
    <td><span class="badge bg-${ST_BADGE[f.status]}">${f.status.replace('_', ' ')}</span></td>
    <td><span class="badge bg-${FRESH_BADGE[f.freshness]}">${f.freshness}</span></td>
    <td class="text-nowrap"><button class="btn btn-sm btn-outline-brand" data-edit="${f.id}">Edit</button>
      <button class="btn btn-sm btn-outline-danger" data-del="${f.id}">Delete</button></td></tr>`).join('');
}
function openFoodModal(f) {
  S.editId = f ? f.id : null;
  $('fTitle').textContent = f ? 'Edit food' : 'Add food';
  $('fCat').innerHTML = S.cats.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
  $('fName').value = f ? f.name : ''; $('fEmoji').value = f ? f.emoji : '🍽️'; $('fDesc').value = f ? f.description || '' : '';
  $('fCat').value = f ? f.category_id : S.cats[0] && S.cats[0].id; $('fPrice').value = f ? f.price : '';
  $('fQty').value = f ? f.quantity : ''; $('fMin').value = f ? f.min_stock : 5; $('fFresh').value = f ? f.freshness : 'GOOD';
  $('fAvail').checked = f ? !!f.is_available : true; $('fSpecial').checked = f ? !!f.is_special : false;
  new bootstrap.Modal($('foodModal')).show();
}
$('addFoodBtn').addEventListener('click', () => openFoodModal(null));
$('foodBody').addEventListener('click', async (e) => {
  const ed = e.target.closest('[data-edit]'); const del = e.target.closest('[data-del]');
  if (ed) openFoodModal(S.foods.find((f) => f.id === Number(ed.dataset.edit)));
  if (del && confirm('Delete this food item?')) {
    try { await api('/food/' + del.dataset.del, { method: 'DELETE' }); toast('Food deleted', 'success'); loadFood(); } catch (err) { toast(err.message, 'danger'); }
  }
});
$('foodForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = { name: $('fName').value, emoji: $('fEmoji').value, description: $('fDesc').value, category_id: Number($('fCat').value),
    price: Number($('fPrice').value), quantity: Number($('fQty').value), min_stock: Number($('fMin').value), freshness: $('fFresh').value,
    is_available: $('fAvail').checked, is_special: $('fSpecial').checked };
  try {
    await api(S.editId ? '/food/' + S.editId : '/food', { method: S.editId ? 'PUT' : 'POST', body });
    bootstrap.Modal.getInstance($('foodModal')).hide(); toast('Food saved', 'success'); loadFood();
  } catch (err) { toast(err.message, 'danger'); }
});

// ---------- Orders ----------
const NEXT = { CONFIRMED: [['ACCEPTED', 'Accept', 'success'], ['CANCELLED', 'Reject', 'danger']], ACCEPTED: [['PREPARING', 'Start preparing', 'primary']],
  PREPARING: [['READY', 'Mark ready', 'success']], READY: [['COMPLETED', 'Complete', 'dark']] };
async function loadOrders() {
  const f = $('orderFilter').value;
  const orders = await api('/orders' + (f ? '?status=' + f : ''));
  $('orderBody').innerHTML = orders.length ? orders.map((o) => `<tr>
    <td>#${o.id}</td><td>${esc(o.customer_name)}</td>
    <td class="small">${o.items.map((i) => `${esc(i.name)} × ${i.quantity}`).join(', ')}${o.notes ? `<div class="text-muted">Note: ${esc(o.notes)}</div>` : ''}</td>
    <td>${money(o.total_amount)}</td><td><span class="badge bg-${OR_BADGE[o.status]}">${o.status}</span></td>
    <td>${o.estimated_minutes ? o.estimated_minutes + ' min' : '-'}</td>
    <td class="text-nowrap">${(NEXT[o.status] || []).map(([s, l, c]) => `<button class="btn btn-sm btn-${c} me-1" data-order="${o.id}" data-status="${s}">${l}</button>`).join('')}</td></tr>`).join('')
    : '<tr><td colspan="7" class="text-muted">No orders.</td></tr>';
}
$('orderFilter').addEventListener('change', loadOrders);
$('orderBody').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-order]'); if (!b) return;
  try { await api(`/orders/${b.dataset.order}/status`, { method: 'PUT', body: { status: b.dataset.status } }); toast('Order updated', 'success'); loadOrders(); }
  catch (err) { toast(err.message, 'danger'); }
});

// ---------- Customers ----------
async function loadCustomers() {
  const rows = await api('/admin/customers?search=' + encodeURIComponent($('custSearch').value.trim()));
  $('custBody').innerHTML = rows.map((c) => `<tr><td>${esc(c.name)}</td><td>${esc(c.email)}</td><td>${esc(c.phone || '-')}</td><td>${c.order_count}</td>
    <td class="small">${fmtDateTime(c.created_at)}</td>
    <td><button class="btn btn-sm ${c.is_active ? 'btn-outline-danger' : 'btn-outline-success'}" data-toggle="${c.id}">${c.is_active ? 'Disable' : 'Enable'}</button></td></tr>`).join('')
    || '<tr><td colspan="6" class="text-muted">No customers found.</td></tr>';
}
let searchTimer;
$('custSearch').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadCustomers, 300); });
$('custBody').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-toggle]'); if (!b) return;
  try { await api(`/admin/customers/${b.dataset.toggle}/toggle`, { method: 'PUT' }); loadCustomers(); } catch (err) { toast(err.message, 'danger'); }
});

// ---------- Seats ----------
async function loadSeats() { const d = await api('/seats'); S.seats = d.seats; S.seatSummary = d.summary; renderSeats(); }
function renderSeats() {
  const s = S.seatSummary; if (!s) return;
  $('seatSummary').innerHTML = `<span><b>Total:</b> ${s.total}</span>` + ['AVAILABLE', 'OCCUPIED', 'RESERVED', 'CLEANING'].map((k) =>
    `<span><span class="legend-dot" style="background:${SEAT_COLOR[k]}"></span><b>${k[0] + k.slice(1).toLowerCase()}:</b> ${s[k]}</span>`).join('');
  $('seatGrid').innerHTML = S.seats.map((t) => `<div class="col-6 col-md-3 col-xl-2"><div class="seat ${t.status}">Table ${t.table_number}
    <small>${t.capacity} seats</small>
    <select class="form-select form-select-sm mt-2" data-seat="${t.id}">${['AVAILABLE', 'OCCUPIED', 'RESERVED', 'CLEANING'].map((k) => `<option ${k === t.status ? 'selected' : ''}>${k}</option>`).join('')}</select></div></div>`).join('');
}
$('seatGrid').addEventListener('change', async (e) => {
  const sel = e.target.closest('[data-seat]'); if (!sel) return;
  try { await api('/seats/' + sel.dataset.seat, { method: 'PUT', body: { status: sel.value } }); } catch (err) { toast(err.message, 'danger'); loadSeats(); }
});

// ---------- Crowd ----------
async function loadCrowd() {
  const [c, h] = await Promise.all([api('/crowd/current'), api('/crowd/history?limit=40')]);
  renderCrowdInfo(c); $('capInput').value = c.max_capacity;
  drawChart('chCrowdHist', { type: 'line', data: { labels: h.map((r) => fmtTime(r.recorded_at)), datasets: [{ label: 'Occupancy %', data: h.map((r) => Number(r.percentage)), borderColor: '#e8590c', backgroundColor: 'rgba(232,89,12,.12)', fill: true, tension: .3 }] }, options: { scales: { y: { min: 0, max: 100 } } } });
}
function renderCrowdInfo(c) {
  $('crowdInfo').innerHTML = `<span class="badge fs-6 lvl-${c.level}">${levelLabel(c.level)}</span>
    <div class="display-6 fw-bold mt-2">${c.people_count}<span class="fs-6 text-muted"> / ${c.max_capacity}</span></div>
    <div class="progress my-2" style="height:14px"><div class="progress-bar lvl-${c.level}" style="width:${Math.min(100, c.percentage)}%"></div></div>
    <div>Occupancy: <b>${c.percentage}%</b></div><div class="small mt-2">${esc(c.recommendation)}</div>`;
}
$('capBtn').addEventListener('click', async () => {
  try { renderCrowdInfo(await api('/crowd/capacity', { method: 'PUT', body: { maxCapacity: Number($('capInput').value) } })); toast('Capacity updated', 'success'); }
  catch (err) { toast(err.message, 'danger'); }
});

// ---------- IoT ----------
async function loadIot() {
  const [devices, readings, foods, seatsData] = await Promise.all([api('/iot/devices'), api('/iot/readings'), api('/food'), api('/seats')]);
  S.foods = foods;
  const icon = { CROWD: '👥', SEAT: '🪑', FOOD: '🍲', WASTE: '⚖️' };
  $('deviceCards').innerHTML = devices.map((d) => `<div class="col-6 col-lg-3"><div class="card stat-card"><span class="stat-icon">${icon[d.device_type]}</span>
    <div class="label">${d.device_type} sensor</div><div class="fw-bold">${d.device_code}</div>
    <span class="badge bg-${d.status === 'ONLINE' ? 'success' : 'secondary'}">${d.status}</span>
    <div class="sub">${esc(d.location || '')}${d.last_seen ? ' · last seen ' + fmtTime(d.last_seen) : ' · never seen'}</div></div></div>`).join('');
  $('simTable').innerHTML = seatsData.seats.map((s) => `<option value="${s.table_number}">Table ${s.table_number}</option>`).join('');
  const opts = foods.map((f) => `<option value="${f.id}">${esc(f.name)}</option>`).join('');
  $('simFood').innerHTML = opts; $('simWasteFood').innerHTML = opts;
  $('readings').innerHTML = `
    <div class="col-md-4"><b class="small">Crowd</b>${readings.crowd.map((r) => `<div class="small text-muted">${fmtTime(r.recorded_at)} · ${r.people_count} people (${r.percentage}%)</div>`).join('')}</div>
    <div class="col-md-4"><b class="small">Food</b>${readings.food.map((r) => `<div class="small text-muted">${fmtTime(r.recorded_at)} · ${esc(r.name)}: ${r.quantity} (${r.freshness})</div>`).join('')}</div>
    <div class="col-md-4"><b class="small">Waste</b>${readings.waste.map((r) => `<div class="small text-muted">${fmtTime(r.recorded_at)} · ${r.meal} ${Number(r.weight_kg).toFixed(1)} kg${r.name ? ' (' + esc(r.name) + ')' : ''}</div>`).join('')}</div>`;
}
async function simulate(path, body, okMsg) {
  try { await api('/iot/' + path, { method: 'POST', body }); toast(okMsg, 'success'); } catch (err) { toast(err.message, 'danger'); }
}
$('simCrowdBtn').addEventListener('click', () => simulate('crowd', { deviceCode: 'CROWD_SENSOR_01', peopleCount: Number($('simPeople').value) }, 'Crowd reading sent'));
$('simSeatBtn').addEventListener('click', () => simulate('seat', { deviceCode: 'SEAT_SENSOR_01', tableNumber: Number($('simTable').value), status: $('simSeatStatus').value }, 'Seat reading sent'));
$('simFoodBtn').addEventListener('click', () => simulate('food', { deviceCode: 'FOOD_SENSOR_01', foodId: Number($('simFood').value), quantity: Number($('simQty').value), freshness: $('simFresh').value }, 'Food reading sent'));
$('simWasteBtn').addEventListener('click', () => simulate('waste', { deviceCode: 'WASTE_SENSOR_01', meal: $('simMeal').value, foodId: Number($('simWasteFood').value), weightKg: Number($('simWeight').value) }, 'Waste reading sent'));

function addFeed(d) {
  const el = $('feed'); if (!el) return;
  const row = document.createElement('div');
  row.className = 'border-bottom py-1';
  row.innerHTML = `<span class="text-muted">${fmtTime(d.at)}</span> <b>${esc(d.deviceCode)}</b> ${esc(d.summary)}`;
  el.prepend(row); while (el.children.length > 40) el.lastChild.remove();
}

// ---------- Waste ----------
async function loadWaste() {
  const w = await api('/waste/summary');
  const cards = [['Today', w.today + ' kg'], ['This week', w.week + ' kg'], ['This month', w.month + ' kg'], ['Waste % (7 days)', w.wastePercentage + '%'], ['Most wasted', esc(w.mostWasted || '-')]];
  $('wasteCards').innerHTML = cards.map(([l, v]) => `<div class="col-6 col-lg"><div class="card stat-card"><div class="label">${l}</div><div class="value">${v}</div></div></div>`).join('');
  drawChart('chWasteTrend', { type: 'line', data: { labels: w.trend.map((t) => t.date.slice(5)), datasets: [{ label: 'kg wasted', data: w.trend.map((t) => t.kg), borderColor: '#7048e8', backgroundColor: 'rgba(112,72,232,.12)', fill: true, tension: .3 }] } });
  $('topWaste').innerHTML = w.topFoods.map((f) => `<div class="d-flex justify-content-between small"><span>${esc(f.name)}</span><b>${f.kg} kg</b></div>`).join('') || '<span class="text-muted small">No data</span>';
  $('mealWaste').innerHTML = ['BREAKFAST', 'LUNCH', 'DINNER'].map((m) => { const r = w.byMeal.find((x) => x.meal === m);
    return `<div class="d-flex justify-content-between small"><span>${m[0] + m.slice(1).toLowerCase()}</span><b>${r ? r.kg : 0} kg</b></div>`; }).join('');
  $('recs').innerHTML = w.recommendations.map((r) => `<div class="alert alert-info py-2 mb-2">${esc(r)}</div>`).join('');
  $('recNote').textContent = w.note;
}

// ---------- Announcements ----------
async function loadAnnouncements() {
  const list = await api('/announcements');
  const icons = { GENERAL: '📢', FOOD: '🍲', EMERGENCY: '🚨', CLOSING: '🕘' };
  $('annList').innerHTML = list.map((a) => `<div class="card ann ${a.type} mb-2"><div class="card-body py-2 d-flex justify-content-between align-items-start">
    <div><b>${icons[a.type]} ${esc(a.title)}</b> <span class="badge bg-secondary">${a.type}</span><div class="small">${esc(a.message)}</div><div class="small text-muted">${fmtDateTime(a.created_at)}</div></div>
    <button class="btn btn-sm btn-outline-danger" data-ann="${a.id}">Remove</button></div></div>`).join('') || '<p class="text-muted">No active announcements.</p>';
}
$('annForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try { await api('/announcements', { method: 'POST', body: { title: $('annTitle').value, message: $('annMsg').value, type: $('annType').value } });
    $('annTitle').value = ''; $('annMsg').value = ''; toast('Announcement published', 'success'); loadAnnouncements(); } catch (err) { toast(err.message, 'danger'); }
});
$('annList').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-ann]'); if (!b) return;
  try { await api('/announcements/' + b.dataset.ann, { method: 'DELETE' }); loadAnnouncements(); } catch (err) { toast(err.message, 'danger'); }
});

// ---------- Real-time ----------
const socket = connectSocket();
const debounced = {};
function refresh(sec, fn) { // refresh the open section once, even if many events arrive together
  if (S.section !== sec) return;
  clearTimeout(debounced[sec]); debounced[sec] = setTimeout(() => fn().catch(() => {}), 400);
}
socket.on('alert', (a) => {
  toast(`${a.title}: ${a.message}`, 'danger');
  const el = document.createElement('div'); el.className = 'alert alert-warning alert-dismissible py-2';
  el.innerHTML = `<b>${esc(a.title)}</b> - ${esc(a.message)}<button class="btn-close" data-bs-dismiss="alert"></button>`;
  $('alertBox').prepend(el); while ($('alertBox').children.length > 4) $('alertBox').lastChild.remove();
});
socket.on('order:new', (o) => { toast(`New order #${o.id} from ${o.customer_name}`, 'info'); refresh('orders', loadOrders); refresh('overview', loadOverview); });
socket.on('order:update', () => { refresh('orders', loadOrders); refresh('overview', loadOverview); });
socket.on('food:update', () => { refresh('food', loadFood); refresh('overview', loadOverview); });
socket.on('seat:update', ({ seat, summary }) => {
  const i = S.seats.findIndex((s) => s.id === seat.id); if (i >= 0) S.seats[i] = seat; S.seatSummary = summary;
  if (S.section === 'seats') renderSeats(); refresh('overview', loadOverview);
});
socket.on('crowd:update', (c) => { if (S.section === 'crowd') { renderCrowdInfo(c); refresh('crowd', loadCrowd); } refresh('overview', loadOverview); });
socket.on('iot:update', (d) => { addFeed(d); });
socket.on('waste:update', () => refresh('waste', loadWaste));
socket.on('queue:update', () => refresh('orders', loadOrders));

show('overview');
