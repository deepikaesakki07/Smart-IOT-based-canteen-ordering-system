// Shared script for ALL customer pages (dashboard, menu, orders, seats, crowd, notifications).
// Every render function checks that its element exists, so each page only uses what it contains.
Auth.require('CUSTOMER');

const state = {
  foods: [], seats: [], seatSummary: null, crowd: null, crowdHistory: [],
  order: null, orders: [], notifs: [], cat: 'All', q: '',
  cart: (() => { try { return JSON.parse(localStorage.getItem('cart')) || {}; } catch (e) { return {}; } })(),
  detailId: null,
};
const ORDER_STEPS = [['CONFIRMED', 'Order Confirmed'], ['ACCEPTED', 'Accepted'], ['PREPARING', 'Preparing'], ['READY', 'Ready for Pickup'], ['COMPLETED', 'Completed']];
const STATUS_BADGE = {
  AVAILABLE: ['success', 'Available'], LOW_STOCK: ['warning text-dark', 'Low stock'],
  NEEDS_RESTOCK: ['warning text-dark', 'Almost gone'], OUT_OF_STOCK: ['secondary', 'Out of stock'],
};
const ORDER_BADGE = { PENDING: 'secondary', CONFIRMED: 'info', ACCEPTED: 'primary', PREPARING: 'warning text-dark', READY: 'success', COMPLETED: 'dark', CANCELLED: 'danger' };

const isOut = (f) => f.status === 'OUT_OF_STOCK';
const foodById = (id) => state.foods.find((f) => f.id === Number(id));
const setT = (id, t) => { const e = $(id); if (e) e.textContent = t; };
const setH = (id, h) => { const e = $(id); if (e) e.innerHTML = h; };
const on = (id, ev, fn) => { const e = $(id); if (e) e.addEventListener(ev, fn); };

// ---------- Shared layout: navbar, cart, profile (built on every page) ----------
function buildLayout() {
  const links = [['dashboard.html', 'Home'], ['menu.html', 'Menu'], ['orders.html', 'My Orders'],
    ['seats.html', 'Seats'], ['crowd.html', 'Crowd'], ['notifications.html', '🔔 Notifications']];
  const here = location.pathname.split('/').pop() || 'dashboard.html';
  $('siteNav').innerHTML = `
  <nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top"><div class="container">
    <a class="navbar-brand" href="dashboard.html">🍽️ Smart Canteen</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navLinks"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navLinks">
      <ul class="navbar-nav me-auto">
        ${links.map(([href, label]) => `<li class="nav-item"><a class="nav-link ${here === href ? 'active fw-bold text-brand' : ''}" href="${href}">${label}${href === 'notifications.html' ? ' <span id="bellBadge" class="badge bg-danger d-none">0</span>' : ''}</a></li>`).join('')}
      </ul>
      <div class="dropdown">
        <button class="btn btn-outline-brand btn-sm dropdown-toggle" data-bs-toggle="dropdown" id="userBtn">Account</button>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="#" id="profileLink">My profile</a></li>
          <li><a class="dropdown-item" href="#" id="logoutLink">Logout</a></li>
        </ul>
      </div>
    </div></div></nav>`;

  $('siteExtras').innerHTML = `
  <button class="btn btn-brand cart-fab" data-bs-toggle="offcanvas" data-bs-target="#cartCanvas">🛒 Cart <span class="badge bg-light text-dark" id="cartCount">0</span></button>
  <div class="offcanvas offcanvas-end" tabindex="-1" id="cartCanvas">
    <div class="offcanvas-header"><h5 class="mb-0">Your cart</h5><button class="btn-close" data-bs-dismiss="offcanvas"></button></div>
    <div class="offcanvas-body d-flex flex-column">
      <div id="cartItems" class="flex-grow-1"></div>
      <div id="cartEstimate" class="alert alert-warning py-2 small d-none"></div>
      <div class="d-flex justify-content-between fw-bold fs-5 mb-2"><span>Total</span><span id="cartTotal">₹0</span></div>
      <input id="orderNotes" class="form-control mb-2" maxlength="200" placeholder="Notes for the kitchen (optional)">
      <button class="btn btn-brand" id="placeOrderBtn">Place order</button>
    </div>
  </div>
  <div class="modal fade" id="profileModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">
    <form id="profileForm">
      <div class="modal-header"><h5 class="modal-title">My profile</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <div class="mb-2"><label class="form-label">Name</label><input id="pName" class="form-control" required></div>
        <div class="mb-2"><label class="form-label">Email</label><input id="pEmail" class="form-control" disabled></div>
        <div class="mb-2"><label class="form-label">Phone</label><input id="pPhone" class="form-control"></div>
      </div>
      <div class="modal-footer"><button class="btn btn-brand">Save</button></div>
    </form></div></div></div>`;
}

// ---------- Rendering ----------
function renderWelcome() {
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  setT('welcome', `${greet}, ${Auth.user.name.split(' ')[0]}! 👋`);
  setT('userBtn', Auth.user.name);
}

function renderCards() {
  if (!$('cardSpecial')) return; // only the Home page has the cards
  const special = state.foods.find((f) => f.is_special && !isOut(f)) || state.foods.find((f) => f.is_special);
  setT('cardSpecial', special ? `${special.emoji} ${special.name}` : 'Not set');
  setT('cardSpecialSub', special ? money(special.price) : '');
  if (state.seatSummary) {
    setT('cardSeats', `${state.seatSummary.AVAILABLE} / ${state.seatSummary.total}`);
    setT('cardSeatsSub', `${state.seatSummary.OCCUPIED} occupied, ${state.seatSummary.RESERVED} reserved`);
  }
  if (state.crowd) {
    setH('cardCrowd', `<span class="badge lvl-${state.crowd.level}">${levelLabel(state.crowd.level)}</span>`);
    setT('cardCrowdSub', `${state.crowd.people_count} people (${state.crowd.percentage}%)`);
  }
  const avail = state.foods.filter((f) => !isOut(f)).length;
  setT('cardFood', `${avail} of ${state.foods.length}`);
  setT('cardFoodSub', 'items available today');
  const o = state.order;
  setT('cardOrder', o ? `#${o.id}` : 'None');
  setT('cardOrderSub', o ? o.status : 'No active order');
  if (!o) { setT('cardPickup', '-'); setT('cardPickupSub', 'Place an order to see it'); }
  else if (o.status === 'READY') { setT('cardPickup', 'Ready now'); setT('cardPickupSub', 'Collect from the counter'); }
  else { setT('cardPickup', o.estimated_minutes ? `~${o.estimated_minutes} min` : '...'); setT('cardPickupSub', o.position_in_queue ? `Queue position ${o.position_in_queue}` : ''); }
}

function renderChips() {
  if (!$('chips')) return;
  const cats = ['All', ...new Set(state.foods.map((f) => f.category).filter(Boolean))];
  setH('chips', cats.map((c) => `<span class="cat-chip ${c === state.cat ? 'active' : ''}" data-cat="${esc(c)}">${esc(c)}</span>`).join(''));
}

function renderMenu() {
  if (!$('menuGrid')) return;
  const q = state.q.toLowerCase();
  const list = state.foods.filter((f) => (state.cat === 'All' || f.category === state.cat) &&
    (!q || f.name.toLowerCase().includes(q) || (f.description || '').toLowerCase().includes(q)));
  if (!list.length) { setH('menuGrid', '<p class="text-muted">No food found.</p>'); return; }
  setH('menuGrid', list.map((f) => {
    const [cls, label] = STATUS_BADGE[f.status];
    return `<div class="col-6 col-md-4 col-lg-3"><div class="card food-card ${isOut(f) ? 'unavailable' : ''}">
      <div class="emoji">${esc(f.emoji)}</div>
      <h6 class="mt-2 mb-1">${esc(f.name)} ${f.is_special ? '⭐' : ''}</h6>
      <div class="small text-muted mb-2">${esc(f.category || '')}</div>
      <div class="mb-2"><span class="badge bg-${cls}">${label}</span>
        ${f.quantity > 0 && f.quantity <= 10 ? `<span class="small text-muted ms-1">${f.quantity} left</span>` : ''}</div>
      <div class="fw-bold mb-2">${money(f.price)}</div>
      <div class="mt-auto d-flex gap-2">
        <button class="btn btn-sm btn-outline-brand flex-fill" data-detail="${f.id}">Details</button>
        <button class="btn btn-sm btn-brand flex-fill" data-add="${f.id}" ${isOut(f) ? 'disabled' : ''}>Add</button>
      </div></div></div>`;
  }).join(''));
}

function renderCart() {
  localStorage.setItem('cart', JSON.stringify(state.cart));
  const ids = Object.keys(state.cart);
  let total = 0; let count = 0;
  setH('cartItems', ids.length ? ids.map((id) => {
    const f = foodById(id); const qty = state.cart[id];
    if (!f) return '';
    total += f.price * qty; count += qty;
    return `<div class="d-flex align-items-center mb-3">
      <div class="fs-3 me-2">${esc(f.emoji)}</div>
      <div class="flex-grow-1"><div class="fw-semibold">${esc(f.name)}</div>
        <div class="small ${isOut(f) ? 'text-danger' : 'text-muted'}">${isOut(f) ? 'Currently unavailable - remove it' : money(f.price) + ' each'}</div></div>
      <div class="btn-group btn-group-sm"><button class="btn btn-outline-secondary" data-dec="${id}">-</button>
        <span class="btn btn-light disabled">${qty}</span><button class="btn btn-outline-secondary" data-inc="${id}">+</button></div>
      <button class="btn btn-sm text-danger" data-rm="${id}">✕</button></div>`;
  }).join('') : '<p class="text-muted">Your cart is empty.</p>');
  setT('cartTotal', money(total));
  setT('cartCount', count);
  $('placeOrderBtn').disabled = !count;
  scheduleEstimate(count);
}

let estTimer;
function scheduleEstimate(count) {
  clearTimeout(estTimer);
  const box = $('cartEstimate');
  if (!count) { box.classList.add('d-none'); return; }
  estTimer = setTimeout(async () => {
    try {
      const e = await api('/orders/estimate', { method: 'POST', body: { itemCount: count } });
      box.classList.remove('d-none');
      box.innerHTML = `⏱️ Estimated pickup: <b>${e.min}-${e.max} minutes</b><br>
        <span class="text-muted">${e.activeOrders} active orders, crowd ${levelLabel(e.crowdLevel)}, avg. prep ${e.avgPrep} min</span>`;
    } catch (err) { box.classList.add('d-none'); }
  }, 300);
}

function renderTracker() {
  if (!$('trackerBox')) return;
  const o = state.order;
  if (!o) {
    setH('trackerBox', '<p class="text-muted mb-2">You have no active order.</p><a href="menu.html" class="btn btn-brand btn-sm">Browse the menu</a>');
    return;
  }
  const idx = ORDER_STEPS.findIndex((s) => s[0] === o.status);
  const steps = ORDER_STEPS.map(([key, label], i) => {
    const cls = i < idx ? 'done' : i === idx ? 'current' : '';
    const sym = i < idx ? '✓' : i === idx ? '●' : '○';
    return `<div class="tracker-step ${cls}"><div class="dot">${sym}</div>${label}</div>`;
  }).join('');
  let eta = '';
  if (o.status === 'READY') eta = '<div class="alert alert-success py-2 mb-2">🎉 Your order is ready for pickup!</div>';
  else if (o.estimated_minutes) eta = `<div class="alert alert-warning py-2 mb-2">Estimated pickup: <b>${o.estimated_minutes} minutes</b> (queue position ${o.position_in_queue})</div>`;
  setH('trackerBox', `
    <div class="d-flex justify-content-between flex-wrap"><h5 class="mb-0">Order #${o.id}</h5><span class="fw-bold">${money(o.total_amount)}</span></div>
    <div class="small text-muted mb-2">${o.items.map((i) => `${esc(i.name)} × ${i.quantity}`).join(', ')}</div>
    ${eta}<div class="tracker">${steps}</div>
    ${o.status === 'CONFIRMED' ? '<button class="btn btn-sm btn-outline-danger mt-2" id="cancelOrderBtn">Cancel order</button>' : ''}`);
}

function renderHistory() {
  if (!$('historyBody')) return;
  setH('historyBody', state.orders.length ? state.orders.map((o) => `<tr>
    <td>#${o.id}</td><td class="small">${o.items.map((i) => `${esc(i.name)} × ${i.quantity}`).join(', ')}</td>
    <td>${money(o.total_amount)}</td><td><span class="badge bg-${ORDER_BADGE[o.status]}">${o.status}</span></td>
    <td class="small">${fmtDateTime(o.created_at)}</td></tr>`).join('') : '<tr><td colspan="5" class="text-muted">No orders yet.</td></tr>');
}

function renderSeats(flashId) {
  if (!$('seatGrid')) return;
  const s = state.seatSummary;
  if (s) setH('seatSummary', `
    <span><b>Total:</b> ${s.total}</span>
    <span><span class="legend-dot" style="background:#2f9e44"></span><b>Available:</b> ${s.AVAILABLE}</span>
    <span><span class="legend-dot" style="background:#e03131"></span><b>Occupied:</b> ${s.OCCUPIED}</span>
    <span><span class="legend-dot" style="background:#f59f00"></span><b>Reserved:</b> ${s.RESERVED}</span>
    <span><span class="legend-dot" style="background:#1c7ed6"></span><b>Cleaning:</b> ${s.CLEANING}</span>`);
  setH('seatGrid', state.seats.map((t) => `<div class="seat ${t.status} ${t.id === flashId ? 'flash' : ''}">
    Table ${t.table_number}<small>${t.status[0] + t.status.slice(1).toLowerCase()} · ${t.capacity} seats</small></div>`).join(''));
  if (flashId) setTimeout(() => document.querySelectorAll('.seat.flash').forEach((e) => e.classList.remove('flash')), 600);
}

function renderCrowd() {
  const c = state.crowd; if (!c || !$('crowdInfo')) return;
  setH('crowdInfo', `
    <div class="mb-2"><span class="badge fs-6 lvl-${c.level}">${levelLabel(c.level)}</span></div>
    <div class="display-6 fw-bold">${c.people_count}<span class="fs-6 text-muted"> / ${c.max_capacity} people</span></div>
    <div class="progress my-2" style="height:14px"><div class="progress-bar lvl-${c.level}" style="width:${Math.min(100, c.percentage)}%"></div></div>
    <div class="mb-2">Occupancy: <b>${c.percentage}%</b></div>
    <div class="small"><b>Recommended:</b> ${esc(c.recommendation)}</div>`);
}

function drawCrowdChart() {
  if (!$('crowdChart') || !state.crowdHistory.length) return;
  drawChart('crowdChart', {
    type: 'line',
    data: {
      labels: state.crowdHistory.map((r) => fmtTime(r.recorded_at)),
      datasets: [{ label: 'Occupancy %', data: state.crowdHistory.map((r) => Number(r.percentage)), borderColor: '#e8590c', backgroundColor: 'rgba(232,89,12,.12)', fill: true, tension: .3 }],
    },
    options: { scales: { y: { min: 0, max: 100, title: { display: true, text: '% of capacity' } } }, plugins: { legend: { display: false } } },
  });
}

function renderAnnouncements(list) {
  if (!$('announcements')) return;
  const icons = { GENERAL: '📢', FOOD: '🍲', EMERGENCY: '🚨', CLOSING: '🕘' };
  setH('announcements', list.slice(0, 3).map((a) => `<div class="card ann ${a.type} mb-2"><div class="card-body py-2">
    <b>${icons[a.type] || '📢'} ${esc(a.title)}</b><div class="small">${esc(a.message)}</div></div></div>`).join(''));
}

function renderNotifs() {
  if ($('notifList')) {
    setH('notifList', state.notifs.length ? state.notifs.slice(0, 30).map((n) => `<div class="notif-item ${n.type}">
      <b>${esc(n.title)}</b> <span class="small text-muted">· ${fmtDateTime(n.created_at)}</span><div class="small">${esc(n.message)}</div></div>`).join('')
      : '<p class="text-muted">No notifications yet.</p>');
  }
  const badge = $('bellBadge'); if (!badge) return;
  if ($('notifList')) localStorage.setItem('notifSeen', new Date().toISOString()); // visiting the page marks all as seen
  const seen = localStorage.getItem('notifSeen') || '1970-01-01';
  const unread = state.notifs.filter((n) => new Date(n.created_at) > new Date(seen)).length;
  badge.textContent = unread; badge.classList.toggle('d-none', !unread);
}

// ---------- Data loading (each page loads only what it shows) ----------
async function loadFood() { state.foods = await api('/food'); renderChips(); renderMenu(); renderCart(); renderCards(); }
async function loadSeats() { const d = await api('/seats'); state.seats = d.seats; state.seatSummary = d.summary; renderSeats(); renderCards(); }
async function loadCrowd() {
  state.crowd = await api('/crowd/current'); state.crowdHistory = await api('/crowd/history?limit=20');
  renderCrowd(); drawCrowdChart(); renderCards();
}
async function loadOrders() {
  state.order = await api('/orders/my/current'); state.orders = await api('/orders/my');
  renderTracker(); renderHistory(); renderCards();
}
async function loadAnnouncements() { renderAnnouncements(await api('/announcements')); }
async function loadNotifs() { state.notifs = await api('/notifications'); renderNotifs(); }

// ---------- Cart actions ----------
function addToCart(id) {
  const f = foodById(id);
  if (!f || isOut(f)) return toast(`${f ? f.name : 'This item'} is currently unavailable.`, 'warning');
  const cur = state.cart[id] || 0;
  if (cur + 1 > Math.min(f.quantity, 20)) return toast(`Only ${f.quantity} of ${f.name} available.`, 'warning');
  state.cart[id] = cur + 1; renderCart(); toast(`${f.name} added to cart`, 'success');
}

function openDetails(id) {
  const f = foodById(id); if (!f) return; state.detailId = id;
  const [cls, label] = STATUS_BADGE[f.status];
  setT('fmTitle', `${f.emoji} ${f.name}`);
  setH('fmBody', `<p>${esc(f.description || 'No description.')}</p>
    <p class="mb-1"><b>Price:</b> ${money(f.price)}</p><p class="mb-1"><b>Category:</b> ${esc(f.category || '-')}</p>
    <p class="mb-1"><b>Status:</b> <span class="badge bg-${cls}">${label}</span></p>
    <p class="mb-0"><b>Freshness (sensor):</b> ${f.freshness}</p>`);
  $('fmAdd').disabled = isOut(f);
  new bootstrap.Modal($('foodModal')).show();
}

function wireEvents() {
  on('menuGrid', 'click', (e) => {
    const add = e.target.closest('[data-add]'); const det = e.target.closest('[data-detail]');
    if (add) addToCart(add.dataset.add);
    if (det) openDetails(det.dataset.detail);
  });
  on('chips', 'click', (e) => { const c = e.target.closest('[data-cat]'); if (c) { state.cat = c.dataset.cat; renderChips(); renderMenu(); } });
  on('searchBox', 'input', (e) => { state.q = e.target.value; renderMenu(); });
  on('fmAdd', 'click', () => { addToCart(state.detailId); bootstrap.Modal.getInstance($('foodModal')).hide(); });

  on('cartItems', 'click', (e) => {
    const inc = e.target.closest('[data-inc]'); const dec = e.target.closest('[data-dec]'); const rm = e.target.closest('[data-rm]');
    if (inc) { const f = foodById(inc.dataset.inc); if (state.cart[inc.dataset.inc] < Math.min(f.quantity, 20)) state.cart[inc.dataset.inc]++; else toast('Maximum available quantity reached', 'warning'); }
    if (dec) { state.cart[dec.dataset.dec]--; if (state.cart[dec.dataset.dec] <= 0) delete state.cart[dec.dataset.dec]; }
    if (rm) delete state.cart[rm.dataset.rm];
    renderCart();
  });

  on('placeOrderBtn', 'click', async () => {
    const items = Object.entries(state.cart).map(([foodId, quantity]) => ({ foodId: Number(foodId), quantity }));
    $('placeOrderBtn').disabled = true;
    try {
      const r = await api('/orders', { method: 'POST', body: { items, notes: $('orderNotes').value } });
      state.cart = {}; $('orderNotes').value = '';
      localStorage.setItem('cart', '{}');
      toast(`Order #${r.order.id} confirmed. Estimated pickup: ${r.estimate.minutes} minutes`, 'success');
      setTimeout(() => { location.href = 'orders.html'; }, 900); // go to the order tracking page
    } catch (err) { toast(err.message, 'danger'); renderCart(); }
  });

  document.addEventListener('click', async (e) => {
    if (e.target.id === 'cancelOrderBtn' && confirm('Cancel this order?')) {
      try { await api(`/orders/${state.order.id}/cancel`, { method: 'PUT' }); toast('Order cancelled', 'info'); await loadOrders(); }
      catch (err) { toast(err.message, 'danger'); }
    }
  });

  on('logoutLink', 'click', (e) => { e.preventDefault(); Auth.logout(); });
  on('profileLink', 'click', async (e) => {
    e.preventDefault();
    const me = await api('/auth/me');
    $('pName').value = me.name; $('pEmail').value = me.email; $('pPhone').value = me.phone || '';
    new bootstrap.Modal($('profileModal')).show();
  });
  on('profileForm', 'submit', async (e) => {
    e.preventDefault();
    try {
      const r = await api('/auth/me', { method: 'PUT', body: { name: $('pName').value, phone: $('pPhone').value.trim() } });
      Auth.save(Auth.token, { ...Auth.user, name: r.name }); renderWelcome();
      bootstrap.Modal.getInstance($('profileModal')).hide(); toast('Profile updated', 'success');
    } catch (err) { toast(err.message, 'danger'); }
  });
}

// ---------- Real-time (Socket.IO) ----------
function wireSocket() {
  const socket = connectSocket();
  socket.on('connect_error', () => toast('Live connection lost. Retrying...', 'warning'));
  socket.on('food:update', (f) => {
    const i = state.foods.findIndex((x) => x.id === f.id);
    if (i >= 0) state.foods[i] = f; else state.foods.push(f);
    renderChips(); renderMenu(); renderCart(); renderCards();
  });
  socket.on('food:removed', ({ id }) => { state.foods = state.foods.filter((f) => f.id !== id); delete state.cart[id]; renderMenu(); renderCart(); renderCards(); });
  socket.on('seat:update', ({ seat, summary }) => {
    const i = state.seats.findIndex((s) => s.id === seat.id); if (i >= 0) state.seats[i] = seat;
    state.seatSummary = summary; renderSeats(seat.id); renderCards();
  });
  socket.on('crowd:update', (c) => {
    state.crowd = c;
    state.crowdHistory.push({ percentage: c.percentage, recorded_at: new Date() });
    if (state.crowdHistory.length > 20) state.crowdHistory.shift();
    renderCrowd(); drawCrowdChart(); renderCards();
  });
  socket.on('order:update', () => { if ($('trackerBox') || $('cardOrder')) loadOrders(); });
  socket.on('queue:update', (q) => {
    if (state.order && state.order.id === q.orderId) {
      state.order.estimated_minutes = q.minutes; state.order.position_in_queue = q.position;
      renderTracker(); renderCards();
    }
  });
  socket.on('announcement', () => { if ($('announcements')) loadAnnouncements(); });
  socket.on('announcement:removed', () => { if ($('announcements')) loadAnnouncements(); });
  socket.on('notification', (n) => {
    state.notifs.unshift(n); renderNotifs();
    toast(`${n.title}: ${n.message}`, toastType(n.type));
  });
}

// ---------- Start ----------
(async function init() {
  buildLayout(); wireEvents(); wireSocket(); renderWelcome();
  const jobs = [loadFood(), loadNotifs()]; // food is needed by the cart on every page
  if ($('seatGrid') || $('cardSeats')) jobs.push(loadSeats());
  if ($('crowdInfo') || $('cardCrowd')) jobs.push(loadCrowd());
  if ($('trackerBox') || $('cardOrder')) jobs.push(loadOrders());
  if ($('announcements')) jobs.push(loadAnnouncements());
  try { await Promise.all(jobs); } catch (err) { toast(err.message, 'danger'); }
})();
