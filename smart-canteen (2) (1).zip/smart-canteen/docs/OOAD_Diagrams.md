# OOAD Diagrams - Smart IoT-Based Canteen Management and Real-Time Monitoring System

These diagrams are written in **Mermaid** so they render in GitHub, VS Code (Markdown Preview Mermaid Support extension)
and https://mermaid.live (paste a block, then export PNG/SVG for your report).

**Note on UML notation:** Mermaid natively supports class, sequence, state and ER diagrams. It has no dedicated
use case, component, deployment or package diagram type, so those four are drawn with flowchart syntax using the
standard UML ideas (actors, ellipses/use cases, components, nodes, packages). If your college requires strict UML
symbols for those four, redraw them in draw.io, StarUML or PlantUML using these as the blueprint.

---

## Actors and use cases (reference)

| Actor | Use cases |
|---|---|
| Customer | Register, Login, View Food, Search Food, Add to Cart, Place Order, Track Order, View Seats, View Crowd, Receive Notifications |
| Admin | Login, Manage Food, Manage Customers, Manage Orders, Manage Seats, Monitor Crowd, Monitor IoT Sensors, Manage Announcements, Monitor Food Waste |
| IoT Sensor (generalised) | Send Crowd Data (Crowd Sensor), Send Seat Data (Seat Sensor), Send Food Data (Food Detection System), Send Waste Data (Waste Sensor) |

---

## 1. Use Case Diagram

```mermaid
flowchart LR
  Customer([Customer])
  Admin([Admin])
  IoT([IoT Sensor])
  Crowd([Crowd Sensor])
  Seat([Seat Sensor])
  Food([Food Detection System])

  Crowd -->|is a| IoT
  Seat -->|is a| IoT
  Food -->|is a| IoT

  subgraph SYS[Smart Canteen System]
    direction TB
    C1((Register))
    C2((Login))
    C3((View / Search Food))
    C4((Add to Cart))
    C5((Place Order))
    C6((Track Order))
    C7((View Seats))
    C8((View Crowd))
    C9((Receive Notifications))
    A1((Manage Food))
    A2((Manage Customers))
    A3((Manage Orders))
    A4((Manage Seats))
    A5((Monitor Crowd))
    A6((Monitor IoT Sensors))
    A7((Manage Announcements))
    A8((Monitor Food Waste))
    I1((Send Crowd Data))
    I2((Send Seat Data))
    I3((Send Food Data))
    I4((Send Waste Data))
  end

  Customer --- C1 & C2 & C3 & C4 & C5 & C6 & C7 & C8 & C9
  Admin --- C2
  Admin --- A1 & A2 & A3 & A4 & A5 & A6 & A7 & A8
  Crowd --- I1
  Seat --- I2
  Food --- I3
  IoT --- I4
  C5 -.->|include| C4
  C6 -.->|include| C9
```

---

## 2. Class Diagram

```mermaid
classDiagram
  class User {
    -int id
    -String name
    -String email
    -String passwordHash
    -boolean isActive
    +login()
    +logout()
    +updateProfile()
  }
  class Customer {
    -int customerId
    -String phone
    +register()
    +viewMenu()
    +placeOrder()
    +trackOrder()
  }
  class Admin {
    -int adminId
    -String designation
    +manageFood()
    +manageOrders()
    +manageCustomers()
    +publishAnnouncement()
  }
  class FoodCategory {
    -int id
    -String name
  }
  class FoodItem {
    -int id
    -String name
    -double price
    -int quantity
    -int minStock
    -FoodStatus status
    -Freshness freshness
    +computeStatus()
    +updateStock()
  }
  class Cart {
    -Map items
    +addItem()
    +changeQuantity()
    +total()
  }
  class Order {
    -int id
    -double totalAmount
    -OrderStatus status
    -DateTime createdAt
    +changeStatus()
    +cancel()
  }
  class OrderItem {
    -int quantity
    -double unitPrice
    +subtotal()
  }
  class QueueRecord {
    -int position
    -int estimatedMinutes
    +recalculate()
  }
  class Seat {
    -int tableNumber
    -int capacity
    -SeatStatus status
    +updateStatus()
  }
  class IoTDevice {
    -String deviceCode
    -DeviceType type
    -DateTime lastSeen
    +sendReading()
  }
  class CrowdSensor {
    +sendPeopleCount()
  }
  class SeatSensor {
    +sendSeatStatus()
  }
  class FoodSensor {
    +sendQuantity()
    +sendFreshness()
  }
  class WasteSensor {
    +sendWeight()
  }
  class CrowdReading {
    -int peopleCount
    -int maxCapacity
    -double percentage
    -CrowdLevel level
    +calculatePercentage()
  }
  class FoodSensorReading {
    -int quantity
    -Freshness freshness
  }
  class WasteRecord {
    -Meal meal
    -double weightKg
    -double preparedKg
  }
  class Notification {
    -String title
    -String message
    -String type
    +send()
  }
  class Announcement {
    -String title
    -String message
    -AnnouncementType type
    +publish()
  }

  User <|-- Customer
  User <|-- Admin
  IoTDevice <|-- CrowdSensor
  IoTDevice <|-- SeatSensor
  IoTDevice <|-- FoodSensor
  IoTDevice <|-- WasteSensor
  Customer "1" --> "0..*" Order : places
  Customer "1" --> "1" Cart : uses
  Order "1" *-- "1..*" OrderItem : contains
  FoodItem "1" --> "0..*" OrderItem : ordered as
  FoodCategory "1" o-- "0..*" FoodItem : groups
  Order "1" --> "0..1" QueueRecord : has
  User "1" --> "0..*" Notification : receives
  Admin "1" --> "0..*" Announcement : publishes
  CrowdSensor "1" --> "0..*" CrowdReading : produces
  FoodSensor "1" --> "0..*" FoodSensorReading : produces
  FoodItem "1" --> "0..*" FoodSensorReading : measured by
  WasteSensor "1" --> "0..*" WasteRecord : produces
  FoodItem "1" --> "0..*" WasteRecord : wasted
  SeatSensor "1" --> "0..*" Seat : updates
```

---

## 3. Sequence Diagram - Place order and get pickup notification

```mermaid
sequenceDiagram
  actor C as Customer
  participant UI as Customer Dashboard
  participant API as Express API
  participant QS as QueueService
  participant DB as MySQL
  participant IO as Socket.IO
  actor A as Admin

  C->>UI: Add items to cart
  UI->>API: POST /orders/estimate
  API->>QS: estimateForNewOrder()
  QS->>DB: count active orders, crowd level
  DB-->>QS: data
  QS-->>UI: 12-18 minutes
  C->>UI: Place order
  UI->>API: POST /orders (JWT)
  API->>DB: BEGIN, lock food rows, reduce stock, insert order and items, COMMIT
  API->>QS: refreshAll()
  API->>IO: food:update, order:new
  IO-->>A: new order alert
  API-->>UI: order confirmed + estimate
  A->>API: PUT /orders/:id/status (ACCEPTED, PREPARING, READY)
  API->>DB: update status, save notification
  API->>IO: order:update + notification
  IO-->>UI: live status and "Ready for pickup"
  A->>API: PUT status COMPLETED
  IO-->>UI: Order completed
```

### 3b. Sequence Diagram - IoT sensor data to live dashboard

```mermaid
sequenceDiagram
  participant S as Crowd Sensor (simulator)
  participant API as Express API /iot/crowd
  participant CS as CrowdService
  participant DB as MySQL
  participant IO as Socket.IO
  participant UI as Customer and Admin UI

  S->>API: POST people_count=85 (x-device-key)
  API->>DB: find device, update last_seen
  API->>CS: record(85)
  CS->>DB: read max capacity, insert crowd reading
  CS->>CS: percentage = 85 / 150 x 100 = 56.7, level = MEDIUM
  CS->>IO: crowd:update
  IO-->>UI: update crowd card and chart (no page refresh)
  CS->>IO: notification if level changed
```

---

## 4. Activity Diagram - Customer ordering workflow

```mermaid
flowchart TD
  Start([Start]) --> Login[Register / Login]
  Login --> Valid{Valid credentials?}
  Valid -- No --> Login
  Valid -- Yes --> Dash[View live canteen status: crowd, seats, food]
  Dash --> Select[Select food]
  Select --> Avail{Food available?}
  Avail -- No --> Select
  Avail -- Yes --> Cart[Add to cart]
  Cart --> Est[View estimated waiting time]
  Est --> Place[Place order]
  Place --> Stock{Stock still enough?}
  Stock -- No --> Err[Show error] --> Select
  Stock -- Yes --> Conf[Order CONFIRMED + notification]
  Conf --> Acc{Admin accepts?}
  Acc -- No --> Canc[CANCELLED, stock restored] --> End([End])
  Acc -- Yes --> Prep[PREPARING]
  Prep --> Ready[READY - pickup notification]
  Ready --> Collect[Customer collects food]
  Collect --> Done[COMPLETED]
  Done --> End
```

---

## 5. State Diagram - Order lifecycle

```mermaid
stateDiagram-v2
  [*] --> PENDING
  PENDING --> CONFIRMED : stock reserved
  CONFIRMED --> ACCEPTED : admin accepts
  CONFIRMED --> CANCELLED : customer cancels / admin rejects
  ACCEPTED --> PREPARING : kitchen starts
  ACCEPTED --> CANCELLED : admin cancels
  PREPARING --> READY : food ready
  READY --> COMPLETED : customer collects
  COMPLETED --> [*]
  CANCELLED --> [*]
```

### 5b. State Diagram - Food item status

```mermaid
stateDiagram-v2
  [*] --> AVAILABLE
  AVAILABLE --> LOW_STOCK : quantity <= minimum
  LOW_STOCK --> NEEDS_RESTOCK : quantity <= half of minimum
  NEEDS_RESTOCK --> OUT_OF_STOCK : quantity = 0
  LOW_STOCK --> OUT_OF_STOCK : quantity = 0
  AVAILABLE --> OUT_OF_STOCK : admin marks unavailable
  OUT_OF_STOCK --> AVAILABLE : restocked above minimum
  LOW_STOCK --> AVAILABLE : restocked above minimum
```

### 5c. State Diagram - Seat

```mermaid
stateDiagram-v2
  [*] --> AVAILABLE
  AVAILABLE --> OCCUPIED : sensor detects people
  AVAILABLE --> RESERVED : reserved
  OCCUPIED --> CLEANING : people leave
  CLEANING --> AVAILABLE : cleaned
  RESERVED --> OCCUPIED : guests arrive
  RESERVED --> AVAILABLE : reservation ends
```

---

## 6. Component Diagram

```mermaid
flowchart LR
  subgraph Client[Browser]
    LoginUI[Login / Register page]
    CustUI[Customer Dashboard]
    AdminUI[Admin Dashboard]
    Charts[Chart.js]
    SockClient[Socket.IO client]
  end
  subgraph Server[Node.js Backend]
    REST[REST API routes]
    Auth[Auth middleware JWT + roles]
    Svc[Services: Food, Seat, Crowd, Queue, Notification]
    SockServer[Socket.IO server]
    DBLayer[MySQL2 connection pool]
  end
  subgraph IoT[IoT Layer]
    Sim[Sensor simulator / real hardware]
  end
  DB[(MySQL database)]

  LoginUI --> REST
  CustUI --> REST
  AdminUI --> REST
  CustUI --- Charts
  AdminUI --- Charts
  SockClient <--> SockServer
  REST --> Auth --> Svc
  Svc --> DBLayer --> DB
  Svc --> SockServer
  Sim -->|HTTP + device key| REST
```

---

## 7. Deployment Diagram

```mermaid
flowchart TB
  subgraph UserDevices[User devices]
    D1[Desktop / Laptop browser]
    D2[Tablet / Mobile browser]
  end
  subgraph SensorNodes[Canteen sensor nodes]
    N1[Crowd sensor / camera]
    N2[Seat sensors]
    N3[Food sensors]
    N4[Weight sensors]
    SIM[Node.js simulator in demo]
  end
  subgraph AppServer[Application server - Node.js]
    EX[Express + Socket.IO\nport 3000]
    ST[Static frontend files]
  end
  subgraph DBServer[Database server]
    MY[(MySQL 3306)]
  end
  D1 -->|HTTP + WebSocket| EX
  D2 -->|HTTP + WebSocket| EX
  N1 -.->|HTTP| EX
  N2 -.->|HTTP| EX
  N3 -.->|HTTP| EX
  N4 -.->|HTTP| EX
  SIM -->|HTTP| EX
  EX --- ST
  EX -->|SQL over TCP| MY
```

---

## 8. Package Diagram

```mermaid
flowchart TB
  subgraph Presentation[frontend]
    P1[pages/customer]
    P2[pages/admin]
    P3[css]
    P4[js]
  end
  subgraph Application[backend/src]
    R[routes]
    M[middleware]
    S[services]
    SO[sockets]
    U[utils]
  end
  subgraph Persistence[data]
    CF[config/db]
    SQ[database/schema.sql]
  end
  subgraph Devices[iot-simulator]
    SM[simulator.js]
  end
  P4 --> R
  P4 --> SO
  R --> M
  R --> S
  S --> CF
  S --> SO
  R --> U
  CF --> SQ
  SM --> R
```

---

## 9. Communication Diagram - Food becomes unavailable

Numbers show the order of messages between objects.

```mermaid
flowchart LR
  Admin[:Admin] -- "1: updateQuantity(Chicken Rice, 0)" --> API[:FoodRoute]
  API -- "2: syncAndPublish()" --> FS[:FoodService]
  FS -- "3: save status OUT_OF_STOCK" --> DB[(:MySQL)]
  FS -- "4: broadcast notification" --> NS[:NotificationService]
  NS -- "5: insert notification" --> DB
  FS -- "6: food:update + notification" --> IO[:SocketServer]
  IO -- "7: 'Chicken Rice is currently unavailable.'" --> Cust[:CustomerBrowser]
  NS -- "8: alert" --> IO
  IO -- "9: low stock alert" --> Admin
```

---

## 10. ER Diagram

```mermaid
erDiagram
  users ||--o| customers : "is a"
  users ||--o| admins : "is an"
  users ||--o{ notifications : receives
  users ||--o{ announcements : publishes
  customers ||--o{ orders : places
  orders ||--|{ order_items : contains
  food_items ||--o{ order_items : "ordered in"
  food_categories ||--o{ food_items : groups
  orders ||--o| queue_records : "has"
  food_items ||--o{ food_sensor_readings : "measured by"
  food_items ||--o{ waste_records : "wasted as"
  iot_devices ||--o{ crowd_readings : sends
  iot_devices ||--o{ food_sensor_readings : sends
  iot_devices ||--o{ waste_records : sends

  users {
    int id PK
    string name
    string email UK
    string password_hash
    enum role
    boolean is_active
  }
  customers {
    int id PK
    int user_id FK
    string phone
  }
  admins {
    int id PK
    int user_id FK
    string designation
  }
  food_categories {
    int id PK
    string name UK
  }
  food_items {
    int id PK
    int category_id FK
    string name
    decimal price
    int quantity
    int min_stock
    enum status
    enum freshness
  }
  orders {
    int id PK
    int customer_id FK
    decimal total_amount
    enum status
    datetime created_at
  }
  order_items {
    int id PK
    int order_id FK
    int food_id FK
    int quantity
    decimal unit_price
  }
  queue_records {
    int id PK
    int order_id FK
    int position_in_queue
    int estimated_minutes
  }
  seats {
    int id PK
    int table_number UK
    int capacity
    enum status
  }
  iot_devices {
    int id PK
    string device_code UK
    enum device_type
    datetime last_seen
  }
  crowd_readings {
    int id PK
    int device_id FK
    int people_count
    int max_capacity
    decimal percentage
    enum level
  }
  food_sensor_readings {
    int id PK
    int device_id FK
    int food_id FK
    int quantity
    enum freshness
  }
  waste_records {
    int id PK
    int device_id FK
    int food_id FK
    enum meal
    decimal weight_kg
    decimal prepared_kg
  }
  notifications {
    int id PK
    int user_id FK
    string title
    string message
    string type
  }
  announcements {
    int id PK
    int admin_id FK
    string title
    string message
    enum type
  }
```

The `seats` table is updated by the seat sensor (`SEAT_SENSOR_01`) through the API; each change is pushed live and is not stored as a separate history table.
The `settings` table (not in the original list) stores `max_capacity` and `avg_prep_minutes`.
