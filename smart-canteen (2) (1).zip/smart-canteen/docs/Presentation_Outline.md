# Presentation Outline (about 15 slides, 10-12 minutes)

1. **Title** - Smart IoT-Based Canteen Management and Real-Time Monitoring System; team, guide, college.
2. **Problem** - long queues, unknown crowd, no seat info, food runs out, food waste, unclear waiting time.
3. **Objectives** - live canteen status, online ordering, pickup prediction, admin control, waste reduction.
4. **Scope and actors** - Customer, Admin, Crowd/Seat/Food/Waste sensors. State clearly: sensors are simulated.
5. **Use case diagram** (OOAD_Diagrams.md #1).
6. **Architecture** - Browser -> REST API -> Express -> MySQL; IoT -> Express -> Socket.IO -> dashboards (component + deployment diagrams).
7. **Class diagram** - inheritance (User, IoTDevice), composition (Order-OrderItem).
8. **ER diagram** - 15 tables and key relationships.
9. **Order workflow** - activity diagram + order state diagram.
10. **Real-time communication** - sequence diagram (IoT -> dashboard) and communication diagram.
11. **Unique module 1: Smart queue and pickup prediction** - formula and example (18 orders, HIGH crowd = 12-18 min).
12. **Unique module 2: Food waste monitoring** - waste dashboard, recommendation logic (suggestion only).
13. **Security** - bcrypt, JWT, RBAC, validation, SQL-injection protection, transactions.
14. **Live demo** - follow the demo script in README section 5.
15. **Limitations and future work, conclusion, Q&A.**

Tips: run the simulator before the demo, keep two browser windows side by side (customer and admin), and have the Simulation Panel ready for the "Chicken Rice goes out of stock" moment.
