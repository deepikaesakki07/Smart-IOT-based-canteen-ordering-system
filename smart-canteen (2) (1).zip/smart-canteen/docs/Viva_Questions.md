# Viva Questions and Answers

## OOAD concepts

**1. What is OOAD and why did you use it?**
Object-Oriented Analysis and Design models a system as interacting objects. We first analysed actors and use cases, then designed classes, states and interactions, and only then coded. It makes the system easier to understand, change and extend.

**2. Who are the actors?**
Customer, Admin and the IoT sensors (Crowd Sensor, Seat Sensor, Food Detection System, plus a Waste Sensor). The sensors are specialisations of a general IoT Sensor actor.

**3. Where did you use inheritance?**
`User` is the parent of `Customer` and `Admin` (the `users` table with a `role`, plus `customers` and `admins` tables). `IoTDevice` is the parent of the Crowd, Seat, Food and Waste sensors (`device_type`).

**4. Where did you use composition and aggregation?**
An `Order` is *composed of* `OrderItem`s (deleting the order deletes its items). A `FoodCategory` *aggregates* `FoodItem`s (a food item survives if the category is removed).

**5. Which design principles did you follow?**
Separation of concerns (routes / services / data), single responsibility (one service per concern: crowd, queue, food), encapsulation (business rules like `computeStatus` live in one place), and a layered architecture.

**6. Which UML diagram would you use to show X?**
Interaction order over time: sequence. Object lifecycle: state diagram. Workflow with decisions: activity. Static structure: class. Hardware and servers: deployment. Code organisation: package / component.

**7. What is the difference between a sequence and a communication diagram?**
Both show interactions. Sequence emphasises time order (vertical lifelines); communication emphasises which objects are linked, with numbered messages.

**8. Explain the order state machine.**
PENDING -> CONFIRMED -> ACCEPTED -> PREPARING -> READY -> COMPLETED. CANCELLED is reachable from CONFIRMED or ACCEPTED. Invalid jumps (for example READY to PREPARING) are rejected by the server.

## Technical

**9. How does real-time update work?**
Browsers connect with Socket.IO using their JWT. The server joins each user to a private room and admins to an `admins` room. When data changes, services call `realtime.emit(...)`, and every connected browser updates its page without refresh.

**10. How is the IoT data handled? Is it real?**
It is simulated. A Node.js simulator (or the admin Simulation Panel) sends readings via HTTP with a device key. With real hardware (ESP32, camera with people counting, load cells) only the sender changes; the backend is unchanged. A website alone cannot detect crowd, seats, stock, freshness or weight.

**11. How is crowd level calculated?**
`percentage = people / max_capacity x 100`. LOW < 30, MEDIUM < 60, HIGH < 85, VERY HIGH >= 85. Example: 85 / 150 = 56.7%, MEDIUM.

**12. Explain the pickup-time prediction.**
`(avg prep + 0.4 per order ahead + 0.5 per extra item + 0.3 per order being prepared) x crowd factor`. The customer sees a range (70%-100% of the value). It is recalculated whenever orders or crowd change. It is a heuristic model, not machine learning, and the coefficients are tunable assumptions.

**13. How do you stop two customers buying the last item?**
Order placement runs in a database transaction and locks the food rows with `SELECT ... FOR UPDATE`. The second request waits, sees the reduced stock and gets a clear error.

**14. How is security implemented?**
bcrypt password hashing, JWT authentication, role-based middleware (`authorize('ADMIN')`), validation on inputs, parameterised SQL queries (SQL-injection safe), disabled-account check on every request, device key for IoT endpoints, central error handling.

**15. How does a customer get blocked from admin APIs?**
The JWT contains the role. `authorize('ADMIN')` returns HTTP 403 for any other role.

**16. Why MySQL (relational)?**
Orders, items, customers and foods have strict relationships and need transactions and foreign keys.

**17. How does the food waste recommendation work?**
For each food, today's waste is compared with its 14-day daily average. If it is more than 1.3 times higher, the system *suggests* reducing preparation by about 10% (15% if more than twice). It never changes anything automatically.

**18. What are the limitations?**
Simulated sensors; heuristic waiting-time model; single canteen; no online payment; no seat reservation by customers (only admin/sensor change seat status); demo-scale only.

**19. Future enhancements?**
Real ESP32 / camera integration with MQTT, online payments, QR pickup, seat reservation by customers, ML-based demand and waiting-time prediction, mobile app, email/SMS notifications.

**20. Why are `customers` and `admins` separate from `users`?**
Shared login data stays in `users`; role-specific data (phone, designation) lives in the child table. This is the relational form of inheritance (table-per-subclass).
