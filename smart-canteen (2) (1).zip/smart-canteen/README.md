# Smart IoT-Based Canteen Management and Real-Time Monitoring System

OOAD college project: a canteen website (customers + admin) with IoT-style real-time monitoring.
Stack: HTML/CSS/JavaScript + Bootstrap 5, Node.js + Express, MySQL, Socket.IO, Chart.js, JWT.

> **Important:** the IoT part is **simulated**. A website cannot physically measure crowd size, seat
> occupancy, food stock, freshness or waste weight. Those values come from a Node.js sensor simulator
> (or the admin Simulation Panel) that sends data the same way real hardware would (HTTP + device key).

---

## 1. Install (once)

| Software | Check with |
|---|---|
| Node.js LTS (18 or newer) | `node -v` |
| MySQL Server 8 | `mysql --version` (or open MySQL Workbench) |

## 2. Configure

```bash
cd smart-canteen/backend
npm install
```

Copy `.env.example` to `.env` and put **your MySQL root password** in `DB_PASSWORD`
(Windows: `copy .env.example .env`, Mac/Linux: `cp .env.example .env`). Also change `JWT_SECRET` to any long random text.

## 3. Create database + demo data

```bash
npm run setup
```

Expected: `Creating database and tables...` then `Done! Demo logins:`.
This **wipes and recreates** all tables, then adds 20 tables, 14 foods, 4 sensors, 6 accounts, 7 days of order history, crowd and waste history.

| Role | Email | Password |
|---|---|---|
| Admin | admin@canteen.com | Admin@123 |
| Customer | student@canteen.com | Student@123 |

## 4. Run

```bash
npm start
```

Open **http://localhost:3000**. Admins go to the admin dashboard, customers to the customer site, which has separate pages: Home, Menu, My Orders, Seats, Crowd and Notifications (shared navbar and cart; every page updates live).

Start the sensor simulator in a **second terminal** (from the `smart-canteen` folder):

```bash
node iot-simulator/simulator.js
```

You will see crowd, seat, food and waste readings being sent, and both dashboards update live without refreshing.

## 5. Demo script (viva)

1. Log in as customer in one browser window and as admin in another (use a private window).
2. Customer: check crowd, seats, menu. Add food to the cart and note the estimated pickup range. Place the order.
3. Admin > Orders: Accept > Start preparing > Mark ready > Complete. The customer tracker and notifications update instantly.
4. Admin > IoT Monitor > Simulation panel: set *Chicken Rice* quantity to `0`. Customer sees "Chicken Rice is currently unavailable." immediately, and the Add button disables.
5. Set quantity to `4` (minimum is 5): admin gets a low-stock alert.
6. Change a table to OCCUPIED: customer seat map flashes and counters change.
7. Send people count `140`: crowd level turns VERY HIGH and everyone is notified.
8. Admin > Food Waste: see recommendations (Chicken Rice waste is high in the demo data).
9. Admin > Announcements: publish a Closing announcement; the customer sees it live.

## 6. Project structure

```
smart-canteen/
├── backend/src/
│   ├── server.js          Express + Socket.IO entry point
│   ├── setup.js           creates DB + demo data (npm run setup)
│   ├── config/db.js       MySQL pool
│   ├── middleware/auth.js JWT, role check, device-key check
│   ├── routes/            REST API (auth, food, orders, seats, crowd, iot, waste, announcements, notifications, admin)
│   ├── services/          business logic (food, seat, crowd, queue prediction, notifications, realtime)
│   └── sockets/           Socket.IO authentication and rooms
├── database/schema.sql    all tables
├── frontend/              index.html (login); pages/customer/ (dashboard, menu, orders, seats, crowd, notifications); pages/admin/; css; js
├── iot-simulator/         sensor simulator
└── docs/                  OOAD diagrams, viva questions, presentation outline
```

## 7. Security implemented

- Passwords hashed with bcrypt (bcryptjs); JWT login; every API except login/register needs a valid token
- Role-based access: `authorize('ADMIN')` protects admin APIs (a customer token gets HTTP 403)
- Disabled accounts are rejected on every request
- Input validation on all write endpoints; parameterised SQL everywhere (`?` placeholders) against SQL injection
- Order placement uses a database transaction with row locks so stock cannot go negative
- IoT endpoints accept only a device API key or an admin token
- Central error handler returns clean JSON errors

## 8. API summary

| Area | Endpoints |
|---|---|
| Auth | `POST /api/auth/register`, `POST /api/auth/login`, `GET/PUT /api/auth/me` |
| Food | `GET /api/food?search=&category=`, admin: `POST`, `PUT /:id`, `DELETE /:id` |
| Orders | `POST /api/orders`, `POST /api/orders/estimate`, `GET /my`, `GET /my/current`, `PUT /:id/cancel`; admin: `GET /`, `PUT /:id/status` |
| Seats | `GET /api/seats`, admin `PUT /api/seats/:id` |
| Crowd | `GET /api/crowd/current`, `GET /history`, admin `PUT /capacity` |
| IoT | `POST /api/iot/crowd|seat|food|waste`, admin `GET /devices`, `GET /readings` |
| Waste | admin `GET /api/waste/summary` |
| Announcements | `GET`, admin `POST`, `DELETE /:id` |
| Admin | `GET /api/admin/stats`, `/analytics`, `/customers`, `PUT /customers/:userId/toggle` |

Socket.IO events: `food:update`, `seat:update`, `crowd:update`, `order:update`, `order:new`, `queue:update`, `announcement`, `notification`, `alert`, `iot:update`, `waste:update`.

## 9. Business rules (good viva material)

- **Crowd %** = `people_count / max_capacity * 100`. LOW < 30, MEDIUM < 60, HIGH < 85, VERY HIGH >= 85.
- **Food status**: qty 0 or unavailable = OUT OF STOCK; qty <= half of minimum = NEEDS RESTOCK; qty <= minimum = LOW STOCK; else AVAILABLE. Freshness (GOOD / WARNING / EXPIRED) is a separate simulated sensor value.
- **Pickup estimate** = `(avg prep + 0.4 x orders ahead + 0.5 x extra items + 0.3 x orders preparing) x crowd factor` (1.0 / 1.1 / 1.25 / 1.5). The range shown is 70% to 100% of that value. Example: 18 orders, HIGH crowd, 7 min = 12-18 min.
- **Waste recommendation** triggers when today's waste for a food is more than 1.3x its 14-day daily average. It is only a suggestion.

## 10. Common errors

| Error | Fix |
|---|---|
| `ER_ACCESS_DENIED_ERROR` | Wrong `DB_PASSWORD` in `backend/.env` |
| `ECONNREFUSED 3306` | MySQL service is not running (Windows: Services > MySQL80 > Start) |
| `JWT_SECRET is missing` | You did not create `backend/.env` from `.env.example` |
| `EADDRINUSE :3000` | Something else uses port 3000; change `PORT` in `.env` |
| Simulator says `cannot reach` | Start the backend first |
| Simulator `ERROR 401/403` | `DEVICE_API_KEY` in `.env` and simulator differ |
| Blank dashboard / redirect to login | Token expired; log in again |

## 11. OOAD documents

See `docs/OOAD_Diagrams.md` (all 10 diagrams in Mermaid), `docs/Viva_Questions.md` and `docs/Presentation_Outline.md`.
