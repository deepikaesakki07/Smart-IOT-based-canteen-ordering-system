// Smart Canteen IoT sensor simulator (Node 18+, no extra packages needed).
// Sends fake crowd / seat / food / waste readings to the backend, exactly like real hardware would:
//   POST /api/iot/<type>   with header  x-device-key
//
// Run:  node iot-simulator/simulator.js
// Stop: Ctrl + C
const BASE = process.env.BASE_URL || 'http://localhost:3000';
const KEY = process.env.DEVICE_API_KEY || 'canteen-device-key-123'; // must match backend/.env

const rand = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
const pick = (arr) => arr[rand(0, arr.length - 1)];

async function send(path, body) {
  try {
    const res = await fetch(`${BASE}/api/iot/${path}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-device-key': KEY }, body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return console.log(`[${path}] ERROR ${res.status}: ${data.message}`);
    return data;
  } catch (e) {
    console.log(`[${path}] cannot reach ${BASE} - is the backend running?`);
  }
}

let people = 60;
let foods = [];

async function loadFoods() {
  try {
    const res = await fetch(`${BASE}/api/iot/foods`, { headers: { 'x-device-key': KEY } });
    foods = res.ok ? await res.json() : [];
  } catch (e) { foods = []; }
}

// CROWD_SENSOR_01 - people count drifts up and down
async function crowdTick() {
  people = Math.max(5, Math.min(160, people + rand(-9, 11)));
  const r = await send('crowd', { deviceCode: 'CROWD_SENSOR_01', peopleCount: people });
  if (r) console.log(`[CROWD_SENSOR_01] people_count=${people} -> ${r.percentage}% ${r.level}`);
}

// SEAT_SENSOR_01 - a random table changes state
async function seatTick() {
  const table = rand(1, 20);
  const status = pick(['AVAILABLE', 'AVAILABLE', 'OCCUPIED', 'OCCUPIED', 'RESERVED', 'CLEANING']);
  const r = await send('seat', { deviceCode: 'SEAT_SENSOR_01', tableNumber: table, status });
  if (r) console.log(`[SEAT_SENSOR_01] Table ${table} -> ${status}`);
}

// FOOD_SENSOR_01 - stock slowly goes down, sometimes the kitchen restocks. Freshness is simulated.
async function foodTick() {
  if (!foods.length) await loadFoods();
  if (!foods.length) return;
  const f = pick(foods);
  f.quantity = Math.random() < 0.12 ? f.quantity + rand(15, 30) : Math.max(0, f.quantity - rand(0, 3));
  const roll = Math.random();
  const freshness = roll < 0.88 ? 'GOOD' : roll < 0.97 ? 'WARNING' : 'EXPIRED';
  const r = await send('food', { deviceCode: 'FOOD_SENSOR_01', foodId: f.id, quantity: f.quantity, freshness });
  if (r) console.log(`[FOOD_SENSOR_01] ${f.name}: qty=${f.quantity} freshness=${freshness} -> ${r.status}`);
}

// WASTE_SENSOR_01 - weight of food returned / thrown away
async function wasteTick() {
  if (!foods.length) await loadFoods();
  const meal = pick(['BREAKFAST', 'LUNCH', 'DINNER']);
  const f = foods.length ? pick(foods) : null;
  const kg = rand(3, 30) / 10;
  const r = await send('waste', { deviceCode: 'WASTE_SENSOR_01', meal, foodId: f ? f.id : undefined, weightKg: kg, preparedKg: Math.round(kg * rand(9, 18) * 10) / 10 });
  if (r) console.log(`[WASTE_SENSOR_01] ${meal} waste ${kg} kg${f ? ' (' + f.name + ')' : ''}`);
}

console.log(`Smart Canteen IoT simulator -> ${BASE}`);
console.log('Press Ctrl+C to stop.\n');
loadFoods().then(() => {
  crowdTick(); seatTick(); foodTick(); wasteTick();
  setInterval(crowdTick, 5000);
  setInterval(seatTick, 7000);
  setInterval(foodTick, 9000);
  setInterval(wasteTick, 30000);
  setInterval(loadFoods, 120000);
});
