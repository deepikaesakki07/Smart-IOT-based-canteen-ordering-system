const jwt = require('jsonwebtoken');

// Every browser connects with its JWT. Admins join the "admins" room,
// every user joins a private room "user:<id>" for personal notifications.
module.exports = (io) => {
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth && socket.handshake.auth.token;
      socket.user = jwt.verify(token, process.env.JWT_SECRET);
      next();
    } catch (e) {
      next(new Error('Authentication failed'));
    }
  });

  io.on('connection', (socket) => {
    socket.join(`user:${socket.user.id}`);
    if (socket.user.role === 'ADMIN') socket.join('admins');
  });
};
