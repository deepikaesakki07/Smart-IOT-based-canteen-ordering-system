const router = require('express').Router();
const db = require('../config/db');
const rt = require('../services/realtime');
const crowd = require('../services/crowdService');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler, HttpError, isInt } = require('../utils/helpers');

router.use(authenticate);

router.get('/current', asyncHandler(async (req, res) => res.json(await crowd.getCurrent())));

router.get('/history', asyncHandler(async (req, res) => {
  const limit = isInt(req.query.limit, 1, 200) ? Number(req.query.limit) : 30;
  const [rows] = await db.query(
    `SELECT * FROM (SELECT id, people_count, percentage, level, recorded_at FROM crowd_readings ORDER BY id DESC LIMIT ?) t ORDER BY id ASC`, [limit]);
  res.json(rows);
}));

// Admin: change maximum capacity
router.put('/capacity', authorize('ADMIN'), asyncHandler(async (req, res) => {
  const max = req.body && req.body.maxCapacity;
  if (!isInt(max, 10, 5000)) throw new HttpError(400, 'Capacity must be a whole number between 10 and 5000');
  await db.query("INSERT INTO settings (name, value) VALUES ('max_capacity', ?) ON DUPLICATE KEY UPDATE value = VALUES(value)", [String(max)]);
  const current = await crowd.getCurrent();
  rt.emit('crowd:update', current);
  res.json(current);
}));

module.exports = router;
