const router = require('express').Router();
const db = require('../config/db');
const rt = require('../services/realtime');
const food = require('../services/foodService');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler, HttpError, isInt } = require('../utils/helpers');

router.use(authenticate);

const SELECT = `SELECT f.*, c.name AS category FROM food_items f LEFT JOIN food_categories c ON c.id = f.category_id`;

// GET /api/food?search=&category=
router.get('/', asyncHandler(async (req, res) => {
  const where = []; const params = [];
  if (req.query.search) { where.push('(f.name LIKE ? OR f.description LIKE ?)'); params.push(`%${req.query.search}%`, `%${req.query.search}%`); }
  if (req.query.category) { where.push('c.name = ?'); params.push(req.query.category); }
  const [rows] = await db.query(`${SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY c.name, f.name`, params);
  res.json(rows);
}));

router.get('/categories', asyncHandler(async (req, res) => {
  const [rows] = await db.query('SELECT * FROM food_categories ORDER BY name');
  res.json(rows);
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const f = await food.getFood(req.params.id);
  if (!f) throw new HttpError(404, 'Food item not found');
  res.json(f);
}));

function validate(b) {
  if (!b.name || String(b.name).trim().length < 2) throw new HttpError(400, 'Food name is required');
  if (isNaN(Number(b.price)) || Number(b.price) < 0) throw new HttpError(400, 'Price must be a positive number');
  if (!isInt(b.quantity, 0, 100000)) throw new HttpError(400, 'Quantity must be a whole number');
  if (!isInt(b.min_stock, 0, 100000)) throw new HttpError(400, 'Minimum stock must be a whole number');
  if (!isInt(b.category_id, 1)) throw new HttpError(400, 'Choose a category');
  if (b.freshness && !['GOOD', 'WARNING', 'EXPIRED'].includes(b.freshness)) throw new HttpError(400, 'Invalid freshness');
}

// ---- Admin only below ----
router.post('/', authorize('ADMIN'), asyncHandler(async (req, res) => {
  const b = req.body || {}; validate(b);
  const [r] = await db.query(
    `INSERT INTO food_items (category_id, name, description, emoji, price, quantity, min_stock, is_available, is_special, freshness)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    [b.category_id, String(b.name).trim(), b.description || null, b.emoji || '🍽️', Number(b.price), Number(b.quantity),
      Number(b.min_stock), b.is_available === false ? 0 : 1, b.is_special ? 1 : 0, b.freshness || 'GOOD']);
  res.status(201).json(await food.syncAndPublish(r.insertId));
}));

router.put('/:id', authorize('ADMIN'), asyncHandler(async (req, res) => {
  const b = req.body || {}; validate(b);
  const [r] = await db.query(
    `UPDATE food_items SET category_id=?, name=?, description=?, emoji=?, price=?, quantity=?, min_stock=?,
       is_available=?, is_special=?, freshness=? WHERE id=?`,
    [b.category_id, String(b.name).trim(), b.description || null, b.emoji || '🍽️', Number(b.price), Number(b.quantity),
      Number(b.min_stock), b.is_available === false ? 0 : 1, b.is_special ? 1 : 0, b.freshness || 'GOOD', req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Food item not found');
  res.json(await food.syncAndPublish(req.params.id));
}));

router.delete('/:id', authorize('ADMIN'), asyncHandler(async (req, res) => {
  try {
    const [r] = await db.query('DELETE FROM food_items WHERE id = ?', [req.params.id]);
    if (!r.affectedRows) throw new HttpError(404, 'Food item not found');
  } catch (err) {
    if (err.code === 'ER_ROW_IS_REFERENCED_2')
      throw new HttpError(409, 'This item has order history and cannot be deleted. Mark it as unavailable instead.');
    throw err;
  }
  rt.emit('food:removed', { id: Number(req.params.id) });
  res.json({ message: 'Food item deleted' });
}));

module.exports = router;
