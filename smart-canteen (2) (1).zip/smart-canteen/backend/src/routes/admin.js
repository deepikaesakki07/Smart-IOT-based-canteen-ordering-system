const router = require('express').Router();
const db = require('../config/db');
const crowd = require('../services/crowdService');
const seats = require('../services/seatService');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler, HttpError } = require('../utils/helpers');

router.use(authenticate, authorize('ADMIN'));

// Dashboard cards
router.get('/stats', asyncHandler(async (req, res) => {
  const one = async (sql) => { const [[r]] = await db.query(sql); return Number(r.n); };
  res.json({
    totalCustomers: await one("SELECT COUNT(*) AS n FROM users WHERE role = 'CUSTOMER'"),
    todaysOrders: await one("SELECT COUNT(*) AS n FROM orders WHERE DATE(created_at) = CURDATE() AND status <> 'CANCELLED'"),
    pendingOrders: await one("SELECT COUNT(*) AS n FROM orders WHERE status IN ('CONFIRMED','ACCEPTED','PREPARING')"),
    lowStockItems: await one("SELECT COUNT(*) AS n FROM food_items WHERE status IN ('LOW_STOCK','NEEDS_RESTOCK','OUT_OF_STOCK')"),
    todaysWaste: Math.round((await one('SELECT COALESCE(SUM(weight_kg),0) AS n FROM waste_records WHERE DATE(recorded_at) = CURDATE()')) * 10) / 10,
    activeSensors: await one("SELECT COUNT(*) AS n FROM iot_devices WHERE last_seen > NOW() - INTERVAL 2 MINUTE"),
    totalSensors: await one('SELECT COUNT(*) AS n FROM iot_devices'),
    seats: await seats.summary(),
    crowd: await crowd.getCurrent(),
  });
}));

// Chart data
router.get('/analytics', asyncHandler(async (req, res) => {
  const [dailyOrders] = await db.query(
    `SELECT DATE_FORMAT(created_at, '%Y-%m-%d') AS d, COUNT(*) AS n FROM orders
     WHERE created_at >= CURDATE() - INTERVAL 6 DAY AND status <> 'CANCELLED' GROUP BY d ORDER BY d`);
  const [foodSales] = await db.query(
    `SELECT f.name, SUM(oi.quantity) AS qty FROM order_items oi
     JOIN orders o ON o.id = oi.order_id JOIN food_items f ON f.id = oi.food_id
     WHERE o.status <> 'CANCELLED' GROUP BY f.id, f.name ORDER BY qty DESC LIMIT 8`);
  const [crowdTrend] = await db.query(
    `SELECT * FROM (SELECT id, people_count, percentage, recorded_at FROM crowd_readings ORDER BY id DESC LIMIT 20) t ORDER BY id ASC`);
  const [wasteTrend] = await db.query(
    `SELECT DATE_FORMAT(recorded_at, '%Y-%m-%d') AS d, ROUND(SUM(weight_kg),1) AS kg FROM waste_records
     WHERE recorded_at >= CURDATE() - INTERVAL 6 DAY GROUP BY d ORDER BY d`);
  res.json({
    dailyOrders: dailyOrders.map((r) => ({ date: r.d, count: Number(r.n) })),
    foodSales: foodSales.map((r) => ({ name: r.name, qty: Number(r.qty) })),
    crowdTrend, wasteTrend: wasteTrend.map((r) => ({ date: r.d, kg: Number(r.kg) })),
    seatOccupancy: await seats.summary(),
  });
}));

// Customers
router.get('/customers', asyncHandler(async (req, res) => {
  const params = []; let where = "WHERE u.role = 'CUSTOMER'";
  if (req.query.search) { where += ' AND (u.name LIKE ? OR u.email LIKE ?)'; params.push(`%${req.query.search}%`, `%${req.query.search}%`); }
  const [rows] = await db.query(
    `SELECT u.id, u.name, u.email, u.is_active, u.created_at, c.phone,
       (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id) AS order_count
     FROM users u JOIN customers c ON c.user_id = u.id ${where} ORDER BY u.id DESC LIMIT 200`, params);
  res.json(rows);
}));

router.put('/customers/:userId/toggle', asyncHandler(async (req, res) => {
  const [r] = await db.query("UPDATE users SET is_active = 1 - is_active WHERE id = ? AND role = 'CUSTOMER'", [req.params.userId]);
  if (!r.affectedRows) throw new HttpError(404, 'Customer not found');
  const [[u]] = await db.query('SELECT id, is_active FROM users WHERE id = ?', [req.params.userId]);
  res.json(u);
}));

module.exports = router;
