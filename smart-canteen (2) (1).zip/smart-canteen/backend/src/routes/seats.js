const router = require('express').Router();
const db = require('../config/db');
const seats = require('../services/seatService');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../utils/helpers');

router.use(authenticate);

router.get('/', asyncHandler(async (req, res) => {
  const [rows] = await db.query('SELECT * FROM seats ORDER BY table_number');
  res.json({ seats: rows, summary: await seats.summary() });
}));

// Admin manual override (the IoT seat sensor uses /api/iot/seat)
router.put('/:id', authorize('ADMIN'), asyncHandler(async (req, res) => {
  res.json(await seats.setStatus(req.params.id, req.body && req.body.status));
}));

module.exports = router;
