const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const { authenticate } = require('../middleware/auth');
const { asyncHandler, HttpError, isEmail } = require('../utils/helpers');

function sign(user, customerId) {
  return jwt.sign({ id: user.id, role: user.role, customerId: customerId || null },
    process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '8h' });
}

// POST /api/auth/register  (customers only)
router.post('/register', asyncHandler(async (req, res) => {
  const { name, email, password, phone } = req.body || {};
  if (!name || String(name).trim().length < 2) throw new HttpError(400, 'Name must be at least 2 characters');
  if (!isEmail(email)) throw new HttpError(400, 'Enter a valid email address');
  if (!password || password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password))
    throw new HttpError(400, 'Password must be at least 8 characters and contain letters and numbers');
  if (phone && !/^[0-9+\-\s]{7,15}$/.test(phone)) throw new HttpError(400, 'Enter a valid phone number');

  const hash = await bcrypt.hash(password, 10);
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [u] = await conn.query(
      "INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,'CUSTOMER')",
      [String(name).trim(), email.toLowerCase(), hash]);
    const [c] = await conn.query('INSERT INTO customers (user_id, phone) VALUES (?,?)', [u.insertId, phone || null]);
    await conn.commit();
    const user = { id: u.insertId, name: String(name).trim(), email: email.toLowerCase(), role: 'CUSTOMER' };
    res.status(201).json({ token: sign(user, c.insertId), user });
  } catch (err) {
    await conn.rollback();
    if (err.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'This email is already registered');
    throw err;
  } finally {
    conn.release();
  }
}));

// POST /api/auth/login  (customers and admins)
router.post('/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  if (!isEmail(email) || !password) throw new HttpError(400, 'Email and password are required');
  const [[u]] = await db.query('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
  if (!u || !(await bcrypt.compare(password, u.password_hash))) throw new HttpError(401, 'Incorrect email or password');
  if (!u.is_active) throw new HttpError(403, 'Your account has been disabled. Contact the canteen admin.');
  let customerId = null;
  if (u.role === 'CUSTOMER') {
    const [[c]] = await db.query('SELECT id FROM customers WHERE user_id = ?', [u.id]);
    customerId = c ? c.id : null;
  }
  res.json({ token: sign(u, customerId), user: { id: u.id, name: u.name, email: u.email, role: u.role } });
}));

// GET /api/auth/me
router.get('/me', authenticate, asyncHandler(async (req, res) => {
  const [[u]] = await db.query(
    `SELECT u.id, u.name, u.email, u.role, u.created_at, c.phone
     FROM users u LEFT JOIN customers c ON c.user_id = u.id WHERE u.id = ?`, [req.user.id]);
  res.json(u);
}));

// PUT /api/auth/me  (update profile)
router.put('/me', authenticate, asyncHandler(async (req, res) => {
  const { name, phone } = req.body || {};
  if (!name || String(name).trim().length < 2) throw new HttpError(400, 'Name must be at least 2 characters');
  if (phone && !/^[0-9+\-\s]{7,15}$/.test(phone)) throw new HttpError(400, 'Enter a valid phone number');
  await db.query('UPDATE users SET name = ? WHERE id = ?', [String(name).trim(), req.user.id]);
  if (req.user.role === 'CUSTOMER') await db.query('UPDATE customers SET phone = ? WHERE user_id = ?', [phone || null, req.user.id]);
  res.json({ message: 'Profile updated', name: String(name).trim() });
}));

module.exports = router;
