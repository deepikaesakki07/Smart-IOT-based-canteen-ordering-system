const router = require('express').Router();
const db = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../utils/helpers');

router.use(authenticate, authorize('ADMIN'));

const round1 = (n) => Math.round(Number(n) * 10) / 10;

// GET /api/waste/summary
router.get('/summary', asyncHandler(async (req, res) => {
  const sum = async (cond) => {
    const [[r]] = await db.query(`SELECT COALESCE(SUM(weight_kg),0) AS w, COALESCE(SUM(prepared_kg),0) AS p FROM waste_records WHERE ${cond}`);
    return r;
  };
  const today = await sum('DATE(recorded_at) = CURDATE()');
  const week = await sum('recorded_at >= CURDATE() - INTERVAL 6 DAY');
  const month = await sum('recorded_at >= CURDATE() - INTERVAL 29 DAY');

  const [byMeal] = await db.query(
    `SELECT meal, SUM(weight_kg) AS kg FROM waste_records WHERE DATE(recorded_at) = CURDATE() GROUP BY meal`);
  const [topFoods] = await db.query(
    `SELECT f.name, SUM(w.weight_kg) AS kg FROM waste_records w JOIN food_items f ON f.id = w.food_id
     WHERE w.recorded_at >= CURDATE() - INTERVAL 6 DAY GROUP BY f.id, f.name ORDER BY kg DESC LIMIT 5`);
  const [trend] = await db.query(
    `SELECT DATE_FORMAT(recorded_at, '%Y-%m-%d') AS d, SUM(weight_kg) AS kg FROM waste_records
     WHERE recorded_at >= CURDATE() - INTERVAL 13 DAY GROUP BY d ORDER BY d`);

  // ---- Recommendations: compare today's waste per food with its 14-day daily average ----
  const [todayFood] = await db.query(
    `SELECT f.name, SUM(w.weight_kg) AS kg FROM waste_records w JOIN food_items f ON f.id = w.food_id
     WHERE DATE(w.recorded_at) = CURDATE() GROUP BY f.id, f.name`);
  const [avgFood] = await db.query(
    `SELECT f.name, SUM(w.weight_kg) / 14 AS avg_kg FROM waste_records w JOIN food_items f ON f.id = w.food_id
     WHERE w.recorded_at >= CURDATE() - INTERVAL 14 DAY AND w.recorded_at < CURDATE() GROUP BY f.id, f.name`);
  const avgMap = Object.fromEntries(avgFood.map((a) => [a.name, Number(a.avg_kg)]));
  const recommendations = [];
  for (const t of todayFood) {
    const avg = avgMap[t.name];
    if (avg && Number(t.kg) > avg * 1.3) {
      const cut = Number(t.kg) > avg * 2 ? 15 : 10;
      recommendations.push(`${t.name} wastage is higher than normal today (${round1(t.kg)} kg vs ${round1(avg)} kg daily average). Suggestion: consider reducing preparation quantity by approximately ${cut}% tomorrow.`);
    }
  }
  const pct = week.p > 0 ? (week.w / week.p) * 100 : 0;
  if (pct > 10) recommendations.push(`Weekly waste is ${round1(pct)}% of food prepared, above the 10% target. Review portion sizes and preparation quantities.`);
  if (!recommendations.length) recommendations.push('Food waste is within the normal range. No action suggested.');

  res.json({
    today: round1(today.w), week: round1(week.w), month: round1(month.w),
    wastePercentage: round1(pct),
    byMeal: byMeal.map((m) => ({ meal: m.meal, kg: round1(m.kg) })),
    topFoods: topFoods.map((f) => ({ name: f.name, kg: round1(f.kg) })),
    mostWasted: topFoods[0] ? topFoods[0].name : null,
    trend: trend.map((t) => ({ date: t.d, kg: round1(t.kg) })),
    recommendations,
    note: 'Recommendations are analytical suggestions only; the canteen manager makes the final decision.',
  });
}));

module.exports = router;
