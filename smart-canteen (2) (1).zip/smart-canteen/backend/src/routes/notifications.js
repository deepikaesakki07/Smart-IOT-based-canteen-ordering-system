const router = require('express').Router();
const db = require('../config/db');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../utils/helpers');

router.use(authenticate);

// Own notifications + broadcasts
router.get('/', asyncHandler(async (req, res) => {
  const [rows] = await db.query(
    'SELECT * FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY id DESC LIMIT 30', [req.user.id]);
  res.json(rows);
}));

router.put('/read-all', asyncHandler(async (req, res) => {
  await db.query('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [req.user.id]);
  res.json({ message: 'All notifications marked as read' });
}));

module.exports = router;
