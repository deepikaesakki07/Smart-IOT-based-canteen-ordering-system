// IoT ingestion endpoints. Real hardware (or the simulator) sends the header
//   x-device-key: <DEVICE_API_KEY>
// The admin "Simulation panel" calls the same endpoints using the admin JWT.
const router = require('express').Router();
const db = require('../config/db');
const rt = require('../services/realtime');
const crowd = require('../services/crowdService');
const seats = require('../services/seatService');
const food = require('../services/foodService');
const { deviceOrAdmin, authenticate, authorize } = require('../middleware/auth');
const { asyncHandler, HttpError, isInt } = require('../utils/helpers');

const DEFAULTS = { CROWD: 'CROWD_SENSOR_01', SEAT: 'SEAT_SENSOR_01', FOOD: 'FOOD_SENSOR_01', WASTE: 'WASTE_SENSOR_01' };

async function getDevice(code, type) {
  const [[d]] = await db.query('SELECT * FROM iot_devices WHERE device_code = ?', [code || DEFAULTS[type]]);
  if (!d) throw new HttpError(404, 'Unknown device code');
  if (d.device_type !== type) throw new HttpError(400, `Device ${d.device_code} is not a ${type} sensor`);
  await db.query('UPDATE iot_devices SET last_seen = NOW() WHERE id = ?', [d.id]);
  return d;
}
const feed = (device, summary) => rt.toAdmins('iot:update', { deviceCode: device.device_code, type: device.device_type, summary, at: new Date() });

// ---- Admin views ----
router.get('/devices', authenticate, authorize('ADMIN'), asyncHandler(async (req, res) => {
  const [rows] = await db.query(
    `SELECT *, IF(last_seen IS NOT NULL AND last_seen > NOW() - INTERVAL 2 MINUTE, 'ONLINE', 'OFFLINE') AS status
     FROM iot_devices ORDER BY device_type, device_code`);
  res.json(rows);
}));

router.get('/readings', authenticate, authorize('ADMIN'), asyncHandler(async (req, res) => {
  const [crowdRows] = await db.query(
    `SELECT r.people_count, r.percentage, r.level, r.recorded_at, d.device_code FROM crowd_readings r
     LEFT JOIN iot_devices d ON d.id = r.device_id ORDER BY r.id DESC LIMIT 8`);
  const [foodRows] = await db.query(
    `SELECT r.quantity, r.freshness, r.recorded_at, f.name, d.device_code FROM food_sensor_readings r
     JOIN food_items f ON f.id = r.food_id JOIN iot_devices d ON d.id = r.device_id ORDER BY r.id DESC LIMIT 8`);
  const [wasteRows] = await db.query(
    `SELECT w.meal, w.weight_kg, w.recorded_at, f.name, d.device_code FROM waste_records w
     LEFT JOIN food_items f ON f.id = w.food_id LEFT JOIN iot_devices d ON d.id = w.device_id ORDER BY w.id DESC LIMIT 8`);
  res.json({ crowd: crowdRows, food: foodRows, waste: wasteRows });
}));

// ---- Ingestion (device key OR admin) ----
router.get('/foods', deviceOrAdmin, asyncHandler(async (req, res) => {
  const [rows] = await db.query('SELECT id, name, quantity, min_stock FROM food_items ORDER BY id');
  res.json(rows);
}));

router.post('/crowd', deviceOrAdmin, asyncHandler(async (req, res) => {
  const { deviceCode, peopleCount } = req.body || {};
  if (!isInt(peopleCount, 0, 100000)) throw new HttpError(400, 'peopleCount must be a whole number');
  const d = await getDevice(deviceCode, 'CROWD');
  const current = await crowd.record(Number(peopleCount), d.id);
  feed(d, `people_count = ${peopleCount} (${current.percentage}%, ${current.level})`);
  res.status(201).json(current);
}));

router.post('/seat', deviceOrAdmin, asyncHandler(async (req, res) => {
  const { deviceCode, tableNumber, status } = req.body || {};
  if (!isInt(tableNumber, 1)) throw new HttpError(400, 'tableNumber is required');
  const d = await getDevice(deviceCode, 'SEAT');
  const [[seat]] = await db.query('SELECT id FROM seats WHERE table_number = ?', [tableNumber]);
  if (!seat) throw new HttpError(404, 'Table not found');
  const updated = await seats.setStatus(seat.id, status);
  feed(d, `Table ${tableNumber} -> ${status}`);
  res.status(201).json(updated);
}));

router.post('/food', deviceOrAdmin, asyncHandler(async (req, res) => {
  const { deviceCode, foodId, quantity, freshness } = req.body || {};
  if (!isInt(foodId, 1) || !isInt(quantity, 0, 100000)) throw new HttpError(400, 'foodId and quantity are required');
  const fr = freshness || 'GOOD';
  if (!['GOOD', 'WARNING', 'EXPIRED'].includes(fr)) throw new HttpError(400, 'Invalid freshness');
  const d = await getDevice(deviceCode, 'FOOD');
  const updated = await food.applySensorReading(d.id, Number(foodId), Number(quantity), fr);
  if (!updated) throw new HttpError(404, 'Food item not found');
  feed(d, `${updated.name}: quantity ${quantity}, freshness ${fr}, status ${updated.status}`);
  res.status(201).json(updated);
}));

router.post('/waste', deviceOrAdmin, asyncHandler(async (req, res) => {
  const { deviceCode, meal, foodId, weightKg, preparedKg } = req.body || {};
  if (!['BREAKFAST', 'LUNCH', 'DINNER'].includes(meal)) throw new HttpError(400, 'meal must be BREAKFAST, LUNCH or DINNER');
  if (isNaN(Number(weightKg)) || Number(weightKg) < 0 || Number(weightKg) > 500) throw new HttpError(400, 'weightKg must be a number between 0 and 500');
  const prepared = isNaN(Number(preparedKg)) ? 0 : Number(preparedKg);
  const d = await getDevice(deviceCode, 'WASTE');
  await db.query('INSERT INTO waste_records (device_id, food_id, meal, weight_kg, prepared_kg) VALUES (?,?,?,?,?)',
    [d.id, foodId && isInt(foodId, 1) ? Number(foodId) : null, meal, Number(weightKg), prepared]);
  feed(d, `${meal} waste: ${Number(weightKg).toFixed(1)} kg`);
  rt.toAdmins('waste:update', { meal, weightKg: Number(weightKg) });
  res.status(201).json({ message: 'Waste record saved' });
}));

module.exports = router;
