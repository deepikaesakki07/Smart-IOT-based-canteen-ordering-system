const router = require('express').Router();
const db = require('../config/db');
const rt = require('../services/realtime');
const food = require('../services/foodService');
const queue = require('../services/queueService');
const notify = require('../services/notificationService');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler, HttpError, isInt } = require('../utils/helpers');

router.use(authenticate);

// Allowed status changes (the order state machine)
const FLOW = {
  PENDING: ['CONFIRMED', 'CANCELLED'],
  CONFIRMED: ['ACCEPTED', 'CANCELLED'],
  ACCEPTED: ['PREPARING', 'CANCELLED'],
  PREPARING: ['READY'],
  READY: ['COMPLETED'],
};

async function loadOrders(whereSql, params) {
  const [orders] = await db.query(
    `SELECT o.*, u.name AS customer_name, c.user_id, q.estimated_minutes, q.position_in_queue
     FROM orders o JOIN customers c ON c.id = o.customer_id JOIN users u ON u.id = c.user_id
     LEFT JOIN queue_records q ON q.order_id = o.id
     ${whereSql} ORDER BY o.id DESC LIMIT 100`, params);
  if (!orders.length) return [];
  const [items] = await db.query(
    `SELECT oi.*, f.name, f.emoji FROM order_items oi JOIN food_items f ON f.id = oi.food_id WHERE oi.order_id IN (?)`,
    [orders.map((o) => o.id)]);
  orders.forEach((o) => { o.items = items.filter((i) => i.order_id === o.id); });
  return orders;
}

const MESSAGES = {
  CONFIRMED: ['Order confirmed', (id) => `Your order #${id} is confirmed.`],
  ACCEPTED: ['Order accepted', (id) => `Order #${id} has been accepted by the kitchen.`],
  PREPARING: ['Preparing your food', (id) => `Order #${id} is now being prepared.`],
  READY: ['Ready for pickup!', (id) => `Order #${id} is ready. Please collect it from the counter.`],
  COMPLETED: ['Order completed', (id) => `Order #${id} is completed. Enjoy your meal!`],
  CANCELLED: ['Order cancelled', (id) => `Order #${id} was cancelled.`],
};

async function changeStatus(orderId, newStatus) {
  const [[order]] = await db.query(
    'SELECT o.*, c.user_id FROM orders o JOIN customers c ON c.id = o.customer_id WHERE o.id = ?', [orderId]);
  if (!order) throw new HttpError(404, 'Order not found');
  if (!(FLOW[order.status] || []).includes(newStatus))
    throw new HttpError(400, `Cannot change order from ${order.status} to ${newStatus}`);

  await db.query('UPDATE orders SET status = ? WHERE id = ?', [newStatus, orderId]);

  if (newStatus === 'CANCELLED') { // give the stock back
    const [items] = await db.query('SELECT food_id, quantity FROM order_items WHERE order_id = ?', [orderId]);
    for (const it of items) {
      await db.query('UPDATE food_items SET quantity = quantity + ? WHERE id = ?', [it.quantity, it.food_id]);
      await food.syncAndPublish(it.food_id);
    }
  }
  if (['READY', 'COMPLETED', 'CANCELLED'].includes(newStatus)) await queue.clearRecord(orderId);

  const [title, msg] = MESSAGES[newStatus];
  await notify.notifyUser(order.user_id, title, msg(orderId), newStatus === 'READY' ? 'PICKUP' : 'ORDER');
  const [updated] = await loadOrders('WHERE o.id = ?', [orderId]);
  rt.toUser(order.user_id, 'order:update', updated);
  rt.toAdmins('order:update', updated);
  await queue.refreshAll();
  return updated;
}

// POST /api/orders/estimate  { itemCount }  -> waiting time shown in the cart
router.post('/estimate', authorize('CUSTOMER'), asyncHandler(async (req, res) => {
  const n = isInt(req.body.itemCount, 1, 200) ? Number(req.body.itemCount) : 1;
  res.json(await queue.estimateForNewOrder(n));
}));

// POST /api/orders  { items:[{foodId, quantity}], notes }
router.post('/', authorize('CUSTOMER'), asyncHandler(async (req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items : [];
  if (!items.length) throw new HttpError(400, 'Your cart is empty');
  if (items.length > 30) throw new HttpError(400, 'Too many items in one order');

  const conn = await db.getConnection();
  let orderId; let total = 0; let itemCount = 0; const touched = [];
  try {
    await conn.beginTransaction();
    const lines = [];
    for (const it of items) {
      if (!isInt(it.foodId, 1) || !isInt(it.quantity, 1, 20)) throw new HttpError(400, 'Invalid item in cart');
      const [[f]] = await conn.query('SELECT * FROM food_items WHERE id = ? FOR UPDATE', [it.foodId]);
      if (!f) throw new HttpError(404, 'A food item in your cart no longer exists');
      const qty = Number(it.quantity);
      if (food.computeStatus(f) === 'OUT_OF_STOCK') throw new HttpError(409, `${f.name} is currently unavailable.`);
      if (f.quantity < qty) throw new HttpError(409, `Only ${f.quantity} of ${f.name} left.`);
      await conn.query('UPDATE food_items SET quantity = quantity - ? WHERE id = ?', [qty, f.id]);
      lines.push({ id: f.id, qty, price: f.price });
      total += f.price * qty; itemCount += qty; touched.push(f.id);
    }
    const [o] = await conn.query(
      "INSERT INTO orders (customer_id, total_amount, status, notes) VALUES (?,?,'CONFIRMED',?)",
      [req.user.customerId, total, req.body.notes ? String(req.body.notes).slice(0, 200) : null]);
    orderId = o.insertId;
    for (const l of lines)
      await conn.query('INSERT INTO order_items (order_id, food_id, quantity, unit_price) VALUES (?,?,?,?)', [orderId, l.id, l.qty, l.price]);
    await conn.commit();
  } catch (err) {
    await conn.rollback(); throw err;
  } finally { conn.release(); }

  for (const id of [...new Set(touched)]) await food.syncAndPublish(id);
  await queue.refreshAll();
  await notify.notifyUser(req.user.id, 'Order confirmed', `Your order #${orderId} is confirmed.`, 'ORDER');
  const [order] = await loadOrders('WHERE o.id = ?', [orderId]);
  rt.toAdmins('order:new', order);
  res.status(201).json({ order, estimate: await queue.estimateForNewOrder(itemCount) });
}));

// GET /api/orders/my  -> order history
router.get('/my', authorize('CUSTOMER'), asyncHandler(async (req, res) => {
  res.json(await loadOrders('WHERE o.customer_id = ?', [req.user.customerId]));
}));

// GET /api/orders/my/current -> latest unfinished order (or null)
router.get('/my/current', authorize('CUSTOMER'), asyncHandler(async (req, res) => {
  const rows = await loadOrders("WHERE o.customer_id = ? AND o.status NOT IN ('COMPLETED','CANCELLED')", [req.user.customerId]);
  res.json(rows[0] || null);
}));

// PUT /api/orders/:id/cancel  (customer, only before the kitchen accepts)
router.put('/:id/cancel', authorize('CUSTOMER'), asyncHandler(async (req, res) => {
  const [[o]] = await db.query('SELECT customer_id, status FROM orders WHERE id = ?', [req.params.id]);
  if (!o || o.customer_id !== req.user.customerId) throw new HttpError(404, 'Order not found');
  if (o.status !== 'CONFIRMED') throw new HttpError(400, 'This order can no longer be cancelled');
  res.json(await changeStatus(req.params.id, 'CANCELLED'));
}));

// ---- Admin ----
router.get('/', authorize('ADMIN'), asyncHandler(async (req, res) => {
  const ok = ['PENDING', 'CONFIRMED', 'ACCEPTED', 'PREPARING', 'READY', 'COMPLETED', 'CANCELLED'];
  if (req.query.status && ok.includes(req.query.status)) return res.json(await loadOrders('WHERE o.status = ?', [req.query.status]));
  res.json(await loadOrders('', []));
}));

router.put('/:id/status', authorize('ADMIN'), asyncHandler(async (req, res) => {
  const status = req.body && req.body.status;
  if (!MESSAGES[status]) throw new HttpError(400, 'Invalid status');
  res.json(await changeStatus(req.params.id, status));
}));

module.exports = router;
