const router = require('express').Router();
const db = require('../config/db');
const rt = require('../services/realtime');
const notify = require('../services/notificationService');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler, HttpError } = require('../utils/helpers');

router.use(authenticate);

const TYPES = ['GENERAL', 'FOOD', 'EMERGENCY', 'CLOSING'];

router.get('/', asyncHandler(async (req, res) => {
  const [rows] = await db.query('SELECT * FROM announcements WHERE is_active = 1 ORDER BY id DESC LIMIT 20');
  res.json(rows);
}));

router.post('/', authorize('ADMIN'), asyncHandler(async (req, res) => {
  const { title, message, type } = req.body || {};
  if (!title || String(title).trim().length < 3) throw new HttpError(400, 'Title must be at least 3 characters');
  if (!message || String(message).trim().length < 3) throw new HttpError(400, 'Message is required');
  if (!TYPES.includes(type)) throw new HttpError(400, 'Invalid announcement type');
  const [r] = await db.query('INSERT INTO announcements (admin_id, title, message, type) VALUES (?,?,?,?)',
    [req.user.id, String(title).trim().slice(0, 120), String(message).trim().slice(0, 500), type]);
  const [[a]] = await db.query('SELECT * FROM announcements WHERE id = ?', [r.insertId]);
  rt.emit('announcement', a);
  await notify.broadcast(type === 'CLOSING' ? 'Canteen closing' : a.title, a.message, type);
  res.status(201).json(a);
}));

router.delete('/:id', authorize('ADMIN'), asyncHandler(async (req, res) => {
  await db.query('UPDATE announcements SET is_active = 0 WHERE id = ?', [req.params.id]);
  rt.emit('announcement:removed', { id: Number(req.params.id) });
  res.json({ message: 'Announcement removed' });
}));

module.exports = router;
