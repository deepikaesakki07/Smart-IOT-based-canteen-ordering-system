require('dotenv').config();
const path = require('path');
const http = require('http');
const express = require('express');
const cors = require('cors');
const { Server } = require('socket.io');

if (!process.env.JWT_SECRET) {
  console.error('JWT_SECRET is missing. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const realtime = require('./services/realtime');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
realtime.init(io);
require('./sockets')(io);

app.use(cors());
app.use(express.json({ limit: '100kb' }));

// REST API
app.use('/api/auth', require('./routes/auth'));
app.use('/api/food', require('./routes/food'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/seats', require('./routes/seats'));
app.use('/api/crowd', require('./routes/crowd'));
app.use('/api/iot', require('./routes/iot'));
app.use('/api/waste', require('./routes/waste'));
app.use('/api/announcements', require('./routes/announcements'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api', (req, res) => res.status(404).json({ message: 'API route not found' }));

// Website (HTML/CSS/JS)
app.use(express.static(path.join(__dirname, '../../frontend')));

// Central error handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err.status) return res.status(err.status).json({ message: err.message });
  if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ message: 'Duplicate entry' });
  console.error(err);
  res.status(500).json({ message: 'Something went wrong on the server' });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Smart Canteen running at http://localhost:${PORT}`));
