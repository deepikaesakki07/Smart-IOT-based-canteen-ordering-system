class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// Lets us use async/await in routes without try/catch everywhere
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const isEmail = (s) => typeof s === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
const isInt = (v, min = -Infinity, max = Infinity) => {
  const n = Number(v);
  return Number.isInteger(n) && n >= min && n <= max;
};

module.exports = { HttpError, asyncHandler, isEmail, isInt };
