// npm run setup  ->  creates the database, all tables and demo data.
// WARNING: wipes existing data in the canteen database.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

const DB = process.env.DB_NAME || 'smart_canteen';
const rand = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
const pick = (arr) => arr[rand(0, arr.length - 1)];
const pad = (n) => String(n).padStart(2, '0');
// local time, same clock MySQL's NOW() uses on this machine
const fmt = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
function daysAgo(n, hour, minute) {
  const d = new Date(); d.setDate(d.getDate() - n); d.setHours(hour, minute, 0, 0); return d;
}
function status(f) { // same rule as foodService.computeStatus
  if (f.qty <= 0) return 'OUT_OF_STOCK';
  if (f.qty <= Math.floor(f.min / 2)) return 'NEEDS_RESTOCK';
  if (f.qty <= f.min) return 'LOW_STOCK';
  return 'AVAILABLE';
}

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost', port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root', password: process.env.DB_PASSWORD || '', multipleStatements: true,
  });
  try {
    console.log('Creating database and tables...');
    await conn.query(`CREATE DATABASE IF NOT EXISTS \`${DB}\` CHARACTER SET utf8mb4`);
    await conn.query(`USE \`${DB}\``);
    await conn.query(fs.readFileSync(path.join(__dirname, '../../database/schema.sql'), 'utf8'));

    console.log('Inserting demo data...');
    const adminHash = await bcrypt.hash('Admin@123', 10);
    const custHash = await bcrypt.hash('Student@123', 10);

    const [a] = await conn.query("INSERT INTO users (name,email,password_hash,role) VALUES ('Canteen Admin','admin@canteen.com',?,'ADMIN')", [adminHash]);
    await conn.query('INSERT INTO admins (user_id) VALUES (?)', [a.insertId]);

    const people = [['Student Demo', 'student@canteen.com'], ['Priya Sharma', 'priya@canteen.com'], ['Arun Kumar', 'arun@canteen.com'],
      ['Meena Iyer', 'meena@canteen.com'], ['Rahul Verma', 'rahul@canteen.com']];
    const customerIds = [];
    for (const [name, email] of people) {
      const [u] = await conn.query("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'CUSTOMER')", [name, email, custHash]);
      const [c] = await conn.query('INSERT INTO customers (user_id, phone) VALUES (?,?)', [u.insertId, '98765' + rand(10000, 99999)]);
      customerIds.push(c.insertId);
    }

    await conn.query("INSERT INTO settings (name,value) VALUES ('max_capacity','150'),('avg_prep_minutes','7')");

    // IoT devices
    const devices = [['CROWD_SENSOR_01', 'CROWD', 'Main entrance'], ['SEAT_SENSOR_01', 'SEAT', 'Dining hall'],
      ['FOOD_SENSOR_01', 'FOOD', 'Serving counter'], ['WASTE_SENSOR_01', 'WASTE', 'Dish return area']];
    const dev = {};
    for (const [code, type, loc] of devices) {
      const [d] = await conn.query('INSERT INTO iot_devices (device_code, device_type, location) VALUES (?,?,?)', [code, type, loc]);
      dev[type] = d.insertId;
    }

    // Categories + food
    const cats = {};
    for (const c of ['Meals', 'Breakfast', 'Snacks', 'Beverages', 'Desserts']) {
      const [r] = await conn.query('INSERT INTO food_categories (name) VALUES (?)', [c]); cats[c] = r.insertId;
    }
    const foods = [
      ['Meals', 'Veg Meals', 'Rice, sambar, rasam, two curries, curd', '🍛', 60, 25, 8, 1],
      ['Meals', 'Chicken Rice', 'Spicy chicken fried rice with raita', '🍗', 90, 5, 5, 0],
      ['Meals', 'Lemon Rice', 'Tangy lemon rice with peanuts', '🍋', 45, 0, 5, 0],
      ['Meals', 'Curd Rice', 'Cooling curd rice with pickle', '🍚', 40, 22, 6, 0],
      ['Meals', 'Egg Fried Rice', 'Wok-tossed rice with egg and veggies', '🍳', 70, 18, 6, 0],
      ['Breakfast', 'Idli (3 pcs)', 'Soft idlis with chutney and sambar', '🥘', 30, 40, 10, 0],
      ['Breakfast', 'Masala Dosa', 'Crispy dosa with potato masala', '🥞', 50, 30, 8, 1],
      ['Breakfast', 'Poori Masala', '2 pooris with potato masala', '🫓', 45, 20, 6, 0],
      ['Snacks', 'Samosa', 'Crispy samosa with mint chutney', '🥟', 15, 35, 10, 0],
      ['Snacks', 'Veg Puff', 'Flaky puff with spiced veg filling', '🥐', 20, 28, 8, 0],
      ['Beverages', 'Filter Coffee', 'South Indian filter coffee', '☕', 15, 60, 15, 0],
      ['Beverages', 'Masala Tea', 'Hot ginger masala tea', '🍵', 12, 55, 15, 0],
      ['Beverages', 'Fresh Lime Soda', 'Sweet or salted lime soda', '🥤', 25, 30, 8, 0],
      ['Desserts', 'Gulab Jamun (2 pcs)', 'Warm gulab jamun in sugar syrup', '🍮', 30, 20, 6, 0],
    ];
    const foodIds = {};
    for (const [cat, name, desc, emoji, price, qty, min, special] of foods) {
      const [r] = await conn.query(
        `INSERT INTO food_items (category_id,name,description,emoji,price,quantity,min_stock,is_special,status) VALUES (?,?,?,?,?,?,?,?,?)`,
        [cats[cat], name, desc, emoji, price, qty, min, special, status({ qty, min })]);
      foodIds[name] = r.insertId;
    }
    const foodList = Object.entries(foodIds);

    // Seats: 20 tables
    const seatStates = ['AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OCCUPIED', 'OCCUPIED', 'RESERVED', 'CLEANING'];
    for (let t = 1; t <= 20; t++) {
      const st = t === 1 ? 'AVAILABLE' : t === 2 ? 'OCCUPIED' : t === 3 ? 'RESERVED' : t === 4 ? 'CLEANING' : pick(seatStates);
      await conn.query('INSERT INTO seats (table_number, capacity, status) VALUES (?,?,?)', [t, t % 5 === 0 ? 6 : t % 3 === 0 ? 2 : 4, st]);
    }

    // Crowd history (last ~2 hours)
    let people_n = 60;
    for (let i = 29; i >= 0; i--) {
      people_n = Math.max(10, Math.min(140, people_n + rand(-12, 14)));
      if (i === 0) people_n = 85; // matches the example in the brief: 85 / 150 = 56.7% MEDIUM
      const pct = Math.round((people_n / 150) * 1000) / 10;
      const level = pct < 30 ? 'LOW' : pct < 60 ? 'MEDIUM' : pct < 85 ? 'HIGH' : 'VERY_HIGH';
      const when = new Date(Date.now() - i * 4 * 60000);
      await conn.query('INSERT INTO crowd_readings (device_id,people_count,max_capacity,percentage,level,recorded_at) VALUES (?,?,?,?,?,?)',
        [dev.CROWD, people_n, 150, pct, level, fmt(when)]);
    }

    // Order history (last 7 days, completed) so charts have data
    for (let day = 6; day >= 0; day--) {
      const n = day === 0 ? rand(3, 6) : rand(8, 16);
      for (let k = 0; k < n; k++) {
        const items = []; const used = new Set(); const lines = rand(1, 3); let total = 0;
        for (let l = 0; l < lines; l++) {
          const [name, id] = pick(foodList); if (used.has(id)) continue; used.add(id);
          const price = foods.find((f) => f[1] === name)[4]; const qty = rand(1, 2);
          items.push([id, qty, price]); total += price * qty;
        }
        const when = fmt(daysAgo(day, rand(8, 13), rand(0, 59)));
        const [o] = await conn.query("INSERT INTO orders (customer_id,total_amount,status,created_at,updated_at) VALUES (?,?,'COMPLETED',?,?)",
          [pick(customerIds), total, when, when]);
        for (const [fid, qty, price] of items)
          await conn.query('INSERT INTO order_items (order_id,food_id,quantity,unit_price) VALUES (?,?,?,?)', [o.insertId, fid, qty, price]);
      }
    }

    // Waste history (30 days): Chicken Rice is deliberately high today to show a recommendation
    const wasteFoods = ['Veg Meals', 'Chicken Rice', 'Curd Rice', 'Idli (3 pcs)', 'Masala Dosa', 'Egg Fried Rice'];
    for (let day = 29; day >= 0; day--) {
      for (const meal of ['BREAKFAST', 'LUNCH', 'DINNER']) {
        const candidates = meal === 'BREAKFAST' ? ['Idli (3 pcs)', 'Masala Dosa'] : meal === 'LUNCH' ? ['Veg Meals', 'Chicken Rice', 'Curd Rice'] : ['Egg Fried Rice', 'Veg Meals', 'Chicken Rice'];
        for (const name of candidates) {
          let kg = (rand(5, 25) / 10); // 0.5 - 2.5 kg
          if (day === 0 && name === 'Chicken Rice') kg = 4.8;
          const prepared = Math.round((kg / (rand(5, 10) / 100)) * 10) / 10;
          const when = fmt(daysAgo(day, meal === 'BREAKFAST' ? 10 : meal === 'LUNCH' ? 15 : 21, rand(0, 50)));
          await conn.query('INSERT INTO waste_records (device_id,food_id,meal,weight_kg,prepared_kg,recorded_at) VALUES (?,?,?,?,?,?)',
            [dev.WASTE, foodIds[name], meal, kg, prepared, when]);
        }
      }
    }
    void wasteFoods;

    await conn.query("INSERT INTO announcements (admin_id,title,message,type) VALUES (?,?,?,?)",
      [a.insertId, 'Welcome to the Smart Canteen', 'Pre-order your food online and skip the queue. Check live seats and crowd before you come!', 'GENERAL']);

    console.log('\nDone! Demo logins:');
    console.log('  Admin    : admin@canteen.com   / Admin@123');
    console.log('  Customer : student@canteen.com / Student@123');
    console.log('\nNext: npm start   then open http://localhost:3000');
  } catch (err) {
    console.error('\nSetup failed:', err.message);
    if (err.code === 'ER_ACCESS_DENIED_ERROR') console.error('Check DB_USER / DB_PASSWORD in backend/.env');
    if (err.code === 'ECONNREFUSED') console.error('MySQL is not running. Start the MySQL service and try again.');
    process.exitCode = 1;
  } finally {
    await conn.end();
  }
})();
