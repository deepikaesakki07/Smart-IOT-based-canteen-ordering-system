const jwt = require('jsonwebtoken');
const db = require('../config/db');

// 1) Verify the JWT and make sure the account is still enabled
async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ message: 'Authentication required' });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const [[user]] = await db.query('SELECT is_active FROM users WHERE id = ?', [payload.id]);
    if (!user || !user.is_active) return res.status(401).json({ message: 'Account disabled or not found' });
    req.user = payload; // { id, role, customerId }
    next();
  } catch (err) {
    res.status(401).json({ message: 'Invalid or expired token' });
  }
}

// 2) Role-based access control
const authorize = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : res.status(403).json({ message: 'Access denied' });

// 3) IoT endpoints: accept either a device API key or an admin JWT
function deviceOrAdmin(req, res, next) {
  if (req.headers['x-device-key'] && req.headers['x-device-key'] === process.env.DEVICE_API_KEY) {
    req.isDevice = true;
    return next();
  }
  authenticate(req, res, () => authorize('ADMIN')(req, res, next));
}

module.exports = { authenticate, authorize, deviceOrAdmin };
