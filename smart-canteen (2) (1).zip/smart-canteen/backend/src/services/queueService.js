const db = require('../config/db');
const rt = require('./realtime');
const crowd = require('./crowdService');

const CROWD_FACTOR = { LOW: 1, MEDIUM: 1.1, HIGH: 1.25, VERY_HIGH: 1.5 };
const ACTIVE = ['CONFIRMED', 'ACCEPTED', 'PREPARING'];

async function getAvgPrep() {
  const [[row]] = await db.query("SELECT value FROM settings WHERE name = 'avg_prep_minutes'");
  return row ? Number(row.value) : 7;
}

/*
 * Waiting-time model (explained in docs):
 *   base      = average preparation time
 *   + 0.4 min for every order ahead in the queue
 *   + 0.5 min for every extra item in this order
 *   + 0.3 min for every order currently being prepared
 *   x crowd factor (LOW 1.0, MEDIUM 1.1, HIGH 1.25, VERY HIGH 1.5)
 * Range shown to the customer: 70% of estimate .. estimate
 * Example: 18 orders ahead, HIGH crowd, 7 min avg, 1 item -> (7 + 7.2) x 1.25 = 17.75 -> 12-18 min
 */
function calc({ ordersAhead, items, preparing, crowdLevel, avgPrep }) {
  const raw = (avgPrep + ordersAhead * 0.4 + Math.max(0, items - 1) * 0.5 + preparing * 0.3) * (CROWD_FACTOR[crowdLevel] || 1);
  const minutes = Math.max(2, Math.round(raw));
  return { minutes, min: Math.max(2, Math.round(raw * 0.7)), max: Math.max(3, minutes) };
}

async function snapshot() {
  const [[a]] = await db.query(`SELECT COUNT(*) AS n FROM orders WHERE status IN ('CONFIRMED','ACCEPTED','PREPARING')`);
  const [[p]] = await db.query(`SELECT COUNT(*) AS n FROM orders WHERE status = 'PREPARING'`);
  const current = await crowd.getCurrent();
  return { activeOrders: Number(a.n), preparing: Number(p.n), crowdLevel: current.level, avgPrep: await getAvgPrep() };
}

// Estimate shown BEFORE the customer places the order (cart)
async function estimateForNewOrder(itemCount) {
  const s = await snapshot();
  const est = calc({ ordersAhead: s.activeOrders, items: itemCount, preparing: s.preparing, crowdLevel: s.crowdLevel, avgPrep: s.avgPrep });
  return { ...est, activeOrders: s.activeOrders, crowdLevel: s.crowdLevel, avgPrep: s.avgPrep };
}

// Recalculate every active order whenever the kitchen queue or crowd changes
async function refreshAll() {
  const s = await snapshot();
  const [orders] = await db.query(
    `SELECT o.id, c.user_id, COALESCE(SUM(oi.quantity),1) AS items
     FROM orders o JOIN customers c ON c.id = o.customer_id
     LEFT JOIN order_items oi ON oi.order_id = o.id
     WHERE o.status IN ('CONFIRMED','ACCEPTED','PREPARING')
     GROUP BY o.id, c.user_id ORDER BY o.id ASC`);
  for (let i = 0; i < orders.length; i++) {
    const o = orders[i];
    const est = calc({ ordersAhead: i, items: Number(o.items), preparing: s.preparing, crowdLevel: s.crowdLevel, avgPrep: s.avgPrep });
    await db.query(
      `INSERT INTO queue_records (order_id, position_in_queue, estimated_minutes) VALUES (?,?,?)
       ON DUPLICATE KEY UPDATE position_in_queue = VALUES(position_in_queue), estimated_minutes = VALUES(estimated_minutes)`,
      [o.id, i + 1, est.minutes]);
    rt.toUser(o.user_id, 'queue:update', { orderId: o.id, position: i + 1, ...est });
  }
  rt.toAdmins('queue:update', { activeOrders: s.activeOrders, preparing: s.preparing });
}

async function clearRecord(orderId) {
  await db.query('DELETE FROM queue_records WHERE order_id = ?', [orderId]);
}

module.exports = { calc, snapshot, estimateForNewOrder, refreshAll, clearRecord, ACTIVE };
