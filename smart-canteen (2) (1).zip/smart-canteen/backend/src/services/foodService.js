const db = require('../config/db');
const rt = require('./realtime');
const notify = require('./notificationService');

// Business rule: how stock quantity maps to a food status
//   unavailable / qty 0        -> OUT_OF_STOCK
//   qty <= half of minimum     -> NEEDS_RESTOCK
//   qty <= minimum             -> LOW_STOCK
//   otherwise                  -> AVAILABLE
function computeStatus(f) {
  if (!f.is_available || f.quantity <= 0) return 'OUT_OF_STOCK';
  if (f.quantity <= Math.floor(f.min_stock / 2)) return 'NEEDS_RESTOCK';
  if (f.quantity <= f.min_stock) return 'LOW_STOCK';
  return 'AVAILABLE';
}

async function getFood(id) {
  const [[f]] = await db.query(
    `SELECT f.*, c.name AS category FROM food_items f
     LEFT JOIN food_categories c ON c.id = f.category_id WHERE f.id = ?`, [id]);
  return f || null;
}

// Recalculate status, save it, push it live and raise alerts when it changed
async function syncAndPublish(foodId) {
  const food = await getFood(foodId);
  if (!food) return null;
  const prev = food.status;
  const status = computeStatus(food);
  if (status !== prev) {
    await db.query('UPDATE food_items SET status = ? WHERE id = ?', [status, foodId]);
    food.status = status;
  }
  rt.emit('food:update', food);

  if (status !== prev) {
    if (status === 'OUT_OF_STOCK') {
      await notify.broadcast('Food unavailable', `${food.name} is currently unavailable.`, 'FOOD');
      await notify.admins('Out of stock', `${food.name} is out of stock.`, 'ALERT');
    } else if (status === 'LOW_STOCK' || status === 'NEEDS_RESTOCK') {
      if (prev === 'AVAILABLE') {
        await notify.broadcast('Low stock', `${food.name} is running low (${food.quantity} left).`, 'FOOD');
      }
      await notify.admins('Low stock alert',
        `${food.name} reached the minimum threshold (${food.quantity} left, minimum ${food.min_stock}).`, 'ALERT');
    } else if (prev === 'OUT_OF_STOCK') {
      await notify.broadcast('Back in stock', `${food.name} is available again.`, 'FOOD');
    }
  }
  return food;
}

// Reading from a (simulated) food sensor
async function applySensorReading(deviceId, foodId, quantity, freshness) {
  const before = await getFood(foodId);
  if (!before) return null;
  await db.query(
    'INSERT INTO food_sensor_readings (device_id, food_id, quantity, freshness) VALUES (?,?,?,?)',
    [deviceId, foodId, quantity, freshness]);
  await db.query('UPDATE food_items SET quantity = ?, freshness = ? WHERE id = ?', [quantity, freshness, foodId]);
  if (freshness === 'EXPIRED' && before.freshness !== 'EXPIRED') {
    await notify.admins('Freshness alert', `${before.name} is reported EXPIRED by the freshness sensor. Remove it from the counter.`, 'ALERT');
  } else if (freshness === 'WARNING' && before.freshness === 'GOOD') {
    await notify.admins('Freshness warning', `${before.name} freshness is at WARNING level.`, 'ALERT');
  }
  return syncAndPublish(foodId);
}

module.exports = { computeStatus, getFood, syncAndPublish, applySensorReading };
