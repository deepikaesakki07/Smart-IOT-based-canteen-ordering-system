const db = require('../config/db');
const rt = require('./realtime');
const notify = require('./notificationService');

// crowd_percentage = people_count / maximum_capacity * 100
function levelFor(pct) {
  if (pct < 30) return 'LOW';
  if (pct < 60) return 'MEDIUM';
  if (pct < 85) return 'HIGH';
  return 'VERY_HIGH';
}

function recommendation(level) {
  return {
    LOW: 'Great time to visit - plenty of space and short queues.',
    MEDIUM: 'Good time to visit. Expect a moderate crowd.',
    HIGH: 'Busy right now. Visiting in 20-30 minutes may be better, or pre-order for pickup.',
    VERY_HIGH: 'Very crowded. Try again in 45+ minutes or order ahead for pickup.',
  }[level];
}

async function getMaxCapacity() {
  const [[row]] = await db.query("SELECT value FROM settings WHERE name = 'max_capacity'");
  return row ? Number(row.value) : 150;
}

async function getCurrent() {
  const max = await getMaxCapacity();
  const [[last]] = await db.query('SELECT * FROM crowd_readings ORDER BY id DESC LIMIT 1');
  const people = last ? last.people_count : 0;
  const percentage = Math.round((people / max) * 1000) / 10;
  const level = levelFor(percentage);
  return {
    people_count: people, max_capacity: max, percentage, level,
    recommendation: recommendation(level), recorded_at: last ? last.recorded_at : null,
  };
}

async function record(peopleCount, deviceId) {
  const before = await getCurrent();
  const max = await getMaxCapacity();
  const percentage = Math.round((peopleCount / max) * 1000) / 10;
  const level = levelFor(percentage);
  await db.query(
    'INSERT INTO crowd_readings (device_id, people_count, max_capacity, percentage, level) VALUES (?,?,?,?,?)',
    [deviceId || null, peopleCount, max, percentage, level]);
  const current = await getCurrent();
  rt.emit('crowd:update', current);
  if (before.level !== level) {
    await notify.broadcast('Crowd level changed', `Canteen crowd is now ${level.replace('_', ' ')} (${percentage}%).`, 'CROWD');
  }
  require('./queueService').refreshAll().catch(() => {}); // crowd affects waiting time
  return current;
}

module.exports = { levelFor, recommendation, getMaxCapacity, getCurrent, record };
