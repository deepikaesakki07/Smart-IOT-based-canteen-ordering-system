const db = require('../config/db');
const rt = require('./realtime');
const { HttpError } = require('../utils/helpers');

const STATUSES = ['AVAILABLE', 'OCCUPIED', 'RESERVED', 'CLEANING'];

async function summary() {
  const [rows] = await db.query('SELECT status, COUNT(*) AS n FROM seats GROUP BY status');
  const s = { AVAILABLE: 0, OCCUPIED: 0, RESERVED: 0, CLEANING: 0, total: 0 };
  rows.forEach((r) => { s[r.status] = Number(r.n); s.total += Number(r.n); });
  return s;
}

async function setStatus(seatId, status) {
  if (!STATUSES.includes(status)) throw new HttpError(400, 'Invalid seat status');
  const [r] = await db.query('UPDATE seats SET status = ? WHERE id = ?', [status, seatId]);
  if (!r.affectedRows) throw new HttpError(404, 'Seat not found');
  const [[seat]] = await db.query('SELECT * FROM seats WHERE id = ?', [seatId]);
  rt.emit('seat:update', { seat, summary: await summary() });
  return seat;
}

module.exports = { STATUSES, summary, setStatus };
