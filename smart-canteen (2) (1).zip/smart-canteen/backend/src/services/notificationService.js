const db = require('../config/db');
const rt = require('./realtime');

// Notify one customer (saved in DB + pushed live)
async function notifyUser(userId, title, message, type = 'INFO') {
  const [r] = await db.query(
    'INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)',
    [userId, title, message, type]
  );
  rt.toUser(userId, 'notification', { id: r.insertId, title, message, type, created_at: new Date() });
}

// Notify everybody (user_id NULL = broadcast)
async function broadcast(title, message, type = 'INFO') {
  const [r] = await db.query(
    'INSERT INTO notifications (user_id, title, message, type) VALUES (NULL,?,?,?)',
    [title, message, type]
  );
  rt.emit('notification', { id: r.insertId, title, message, type, created_at: new Date() });
}

// Alert all admins (stock alerts, expired food, ...)
async function admins(title, message, type = 'ALERT') {
  const [rows] = await db.query("SELECT id FROM users WHERE role='ADMIN' AND is_active=1");
  for (const a of rows) {
    await db.query('INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)', [a.id, title, message, type]);
  }
  rt.toAdmins('alert', { title, message, type, created_at: new Date() });
}

module.exports = { notifyUser, broadcast, admins };
