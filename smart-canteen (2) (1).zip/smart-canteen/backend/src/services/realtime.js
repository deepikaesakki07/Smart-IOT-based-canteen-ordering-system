// Thin wrapper around Socket.IO so any service can push live updates.
let io = null;

module.exports = {
  init(instance) { io = instance; },
  emit(event, payload) { if (io) io.emit(event, payload); },             // everyone
  toAdmins(event, payload) { if (io) io.to('admins').emit(event, payload); },
  toUser(userId, event, payload) { if (io) io.to(`user:${userId}`).emit(event, payload); },
};
